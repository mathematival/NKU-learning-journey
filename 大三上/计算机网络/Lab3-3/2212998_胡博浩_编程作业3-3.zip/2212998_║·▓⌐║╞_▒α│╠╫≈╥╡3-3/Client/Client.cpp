﻿#include "Message.h"
#include <fstream>
#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <atomic>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

class Client : UDP {
private:
    SOCKET clientSocket;                // 客户端 socket
    SOCKADDR_IN clientAddr;             // 客户端地址
    SOCKADDR_IN routerAddr;             // 路由器地址

    atomic<bool> running;               // 是否正在发送数据
    atomic<bool> resend;                // 是否需要重传标志
    atomic<ULONGLONG> timerStart;       // 计时器起始时间
    uint32_t windowSize;                // 窗口大小（应该等于接收窗口大小，这个实验没用）
    uint32_t nextSeq;                   // 下一个序列号
    uint32_t base;                      // 窗口基序号
    vector<Message> sendBuffer;         // 发送缓冲区
    mutex bufferMtx;                    // 保护发送缓冲区

    mutex printMtx;                     // 保护打印

    // 拥塞控制相关变量
    uint32_t cwnd;                      // 拥塞窗口大小
    uint32_t ssthresh;                  // 慢启动阈值
    enum CongestionState { SLOW_START, CONGESTION_AVOIDANCE, FAST_RECOVERY };
    CongestionState state;              // 拥塞控制状态
    uint32_t dupAckCount;               // 重复 ACK 计数
    uint32_t cwnd_increment;            // 拥塞窗口增量（用于拥塞避免阶段）

    void resendPackets();               // 重传窗口内的所有包
    void printWindowStatus();           // 窗口信息打印函数
    void setMsg(Message& msg);          // 设置报文
    bool sendMessage(Message& msg);     // 实现单个报文发送
public:
    Client() : clientSocket(INVALID_SOCKET), running(false), timerStart(0), resend(false) {
        isConnected = false; nextSeq = 0; base = 0; windowSize = 24;
        cwnd = 4; ssthresh = 64; state = SLOW_START; dupAckCount = 0; cwnd_increment = 0;
    }
    ~Client() {
        if (clientSocket != INVALID_SOCKET) {
            closesocket(clientSocket);
            clientSocket = INVALID_SOCKET;
        }
        WSACleanup();
    }
    bool initialize();                  // 初始化客户端
    bool threeWayHandshake();           // 实现三次握手
    void sendFile(const string& filename); // 实现文件传输
    bool fourWayHandwave();             // 实现四次挥手
    void waitExit();                    //等待退出
    void run();                         // 运行客户端

    static DWORD WINAPI receiveAck(LPVOID pParam); // 接收ACK的线程函数
    void print(const string& info, Level level) {
        lock_guard<mutex> lock(printMtx);
        UDP::print(info, level);
    }
    void printMessageInfo(const Message& msg, const string& prefix, Level level) {
        lock_guard<mutex>lock(printMtx);
        UDP::printMessageInfo(msg, prefix, level);
    }
};

// 初始化客户端
bool Client::initialize() {
    // 初始化 Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        print("Winsock 初始化失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("Winsock 初始化成功", INFO);
    // 创建客户端套接字, 使用 UDP 协议
    clientSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (clientSocket == INVALID_SOCKET) {
        print("创建socket失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    // 设置非阻塞模式
    u_long mode = 1;
    if (ioctlsocket(clientSocket, FIONBIO, &mode) != 0) {
        print("无法设置socket为非阻塞模式: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("创建socket成功", INFO);
    // 初始化路由器地址
    routerAddr.sin_family = AF_INET;// 使用 IPv4 地址
    routerAddr.sin_port = htons(routerPORT);
    inet_pton(AF_INET, routerIP, &routerAddr.sin_addr);
    // 初始化客户端地址
    clientAddr.sin_family = AF_INET;
    clientAddr.sin_port = htons(clientPORT);
    inet_pton(AF_INET, clientIP, &clientAddr.sin_addr);
    // 绑定客户端地址
    if (bind(clientSocket, (SOCKADDR*)&clientAddr, sizeof(clientAddr)) == SOCKET_ERROR) {
        print("绑定客户端地址失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("绑定客户端地址成功", INFO);
    return true;
}

// 设置报文
void Client::setMsg(Message& sendMsg) {
    sendMsg.srcPort = clientPORT;
    sendMsg.destPort = routerPORT;
    sendMsg.setCheckSum();
}

// 窗口信息打印函数
void Client::printWindowStatus() {
    print("拥塞窗口状态：cwnd=" + to_string(cwnd) + ", ssthresh=" + to_string(ssthresh) + ", base=" + to_string(base) + ", nextSeq=" + to_string(nextSeq), INFO);
}

// 重传窗口内的所有包
void Client::resendPackets() {
    vector<Message> bufferCopy;
    {
        lock_guard<mutex> lock(bufferMtx);
        bufferCopy = sendBuffer;  // 复制一份再发送
    }
    print("重传窗口内的所有包", WARN);
    for (const auto& msg : bufferCopy) {
        sendtoWithSimulation(clientSocket, (char*)&msg, sizeof(msg), 0, (sockaddr*)&routerAddr, sizeof(routerAddr));
        printMessageInfo(msg, "重传报文：", SEND);
    }
    timerStart.store(GetTickCount64()); // 重新开始计时
    resend.store(false);
}

// 接收ACK的线程函数
DWORD WINAPI Client::receiveAck(LPVOID pParam) {
    Client* client = (Client*)pParam;
    int addrLen = sizeof(client->routerAddr);
    while (client->running.load()) {
        client->recvMsg.clean();
        int recvBytes = recvfrom(client->clientSocket, (char*)&client->recvMsg, sizeof(client->recvMsg),
            0, (sockaddr*)&client->routerAddr, &addrLen);
        if (recvBytes > 0 && client->recvMsg.checkSum() && client->recvMsg.is_ACK()) {
            // 累积确认逻辑：接受大于base的ACK
            if (client->recvMsg.ackNum > client->base) {
                client->print("收到ACK: " + to_string(client->recvMsg.ackNum), RECV);
                {
                    lock_guard<mutex> lock(client->bufferMtx);
                    if (!client->sendBuffer.empty()) {// 移除已确认的包
                        client->sendBuffer.erase(client->sendBuffer.begin(), client->sendBuffer.begin() + (client->recvMsg.ackNum - client->sendBuffer.front().seqNum));
                    }
                }
                client->base = client->recvMsg.ackNum;// 更新发送窗口
                // 拥塞控制逻辑
                client->dupAckCount = 0;
                if (client->state == FAST_RECOVERY) {
                    // 从快速恢复阶段进入拥塞避免阶段
                    client->cwnd = client->ssthresh;
                    client->state = CONGESTION_AVOIDANCE;
                    client->print("退出快速恢复阶段，进入拥塞避免阶段", WARN);
                    client->cwnd_increment = 0;
                }
                else if (client->state == SLOW_START) {
                    client->cwnd += 1;
                    if (client->cwnd >= client->ssthresh) {
                        client->state = CONGESTION_AVOIDANCE;
                        client->print("进入拥塞避免阶段", WARN);
                        client->cwnd_increment = 0;
                    }
                }
                else if (client->state == CONGESTION_AVOIDANCE) {
                    client->cwnd_increment++;
                    if (client->cwnd_increment == client->cwnd) {
                        client->cwnd++;  // 每轮 RTT 增加 1
                        client->cwnd_increment = 0;
                    }
                }
                client->printWindowStatus();
                // 重置计时器
                if (client->base != client->nextSeq) {
                    client->timerStart.store(GetTickCount64()); // 重新开始计时
                }
                else {
                    client->timerStart.store(0); // 所有包都已确认
                }
            }
            else {// 收到重复ACK
                if (client->state == FAST_RECOVERY) {
                    // 在快速恢复阶段，每收到一个重复 ACK，cwnd 增加 1
                    client->print("收到重复ACK: " + to_string(client->recvMsg.ackNum), WARN);
                    client->cwnd++;
                    client->printWindowStatus();
                }
                else {
                    // 收到重复 ACK
                    client->dupAckCount++;
                    client->print("收到重复ACK: " + to_string(client->recvMsg.ackNum) +
                        ", 重复次数: " + to_string(client->dupAckCount), WARN);
                    if (client->dupAckCount == 3) {
                        client->resend.store(true);
                        client->dupAckCount = 0;
                        // 收到三次重复 ACK，进入快速恢复阶段
                        client->ssthresh = max(client->cwnd / 2, 2U); // 设定最小阈值为2
                        client->cwnd = client->ssthresh + 3;
                        client->state = FAST_RECOVERY;
                        client->print("进入快速恢复阶段", WARN);
                        client->printWindowStatus();
                        client->resendPackets();
                    }
                }
            }
        }
        // 检查超时
        if (client->timerStart.load() != 0 && GetTickCount64() - client->timerStart.load() > MAX_WAIT_TIME) {
            client->resend.store(true);
            client->ssthresh = max(client->cwnd / 2, 2U); // 设定最小阈值为2
            client->cwnd = 1;
            client->state = SLOW_START;
            client->dupAckCount = 0;
            client->print("超时发生，进入慢启动阶段", WARN);
            client->printWindowStatus();
            client->resendPackets();
        }
    }
    return 0;
}

//实现单个报文发送
bool Client::sendMessage(Message& msg) {
    int retries = 0;
    while (retries < MAX_SEND_TIMES) {
        printMessageInfo(msg, "发送报文：", SEND);
        sendtoWithSimulation(clientSocket, (char*)&msg, sizeof(msg), 0, (sockaddr*)&routerAddr, sizeof(SOCKADDR_IN));
        cout << endl;

        clock_t start = clock();
        while (clock() - start < MAX_WAIT_TIME) {
            recvMsg.clean();
            int addrLen = sizeof(routerAddr);
            int recvBytes = recvfrom(clientSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &addrLen);
            if (recvBytes > 0 && recvMsg.checkSum()) {
                if (recvMsg.is_ACK() && recvMsg.ackNum == nextSeq) {
                    print("收到确认: ack = " + to_string(recvMsg.ackNum), RECV);
                    return true;
                }
            }
        }
        print("报文序号=" + to_string(msg.seqNum) + " 第" + to_string(++retries) + "次超时重传", WARN);
    }
    print("达到最大重传次数，发送失败", ERR);
    return false;
}

// 实现文件传输
void Client::sendFile(const string& filename) {
    try {
        ifstream file("测试文件\\" + filename, ios::binary);
        if (!file) {
            throw runtime_error("无法打开文件");
        }
        // 获取文件大小
        file.seekg(0, ios::end);
        size_t fileSize = file.tellg();
        file.seekg(0, ios::beg);
        // 分配内存并读取文件
        vector<uint8_t> fileBuffer(fileSize);
        if (!file.read((char*)fileBuffer.data(), fileSize)) {
            throw runtime_error("文件读取失败");
        }
        print("文件读取成功，大小为 " + to_string(fileSize) + " bytes", INFO);
        // 发送文件信息：文件名、文件大小
        sendMsg.clean();
        sendMsg.set_FILE_NAME();
        sendMsg.length = fileSize;
        strncpy_s((char*)sendMsg.data, MAX_MSG_SIZE, filename.c_str(), filename.length());
        sendMsg.seqNum = nextSeq++;
        setMsg(sendMsg);
        if (!sendMessage(sendMsg)) {
            throw runtime_error("文件信息发送失败");
        }
        print("文件信息发送成功", INFO);
        base = nextSeq;
        // 分片发送
        uint32_t totalPackets = (fileSize + MAX_MSG_SIZE - 1) / MAX_MSG_SIZE;
        print("开始发送文件，总包数：" + to_string(totalPackets), INFO);
        auto startTime = chrono::steady_clock::now();
        // 启动接收ACK线程
        running.store(true);
        HANDLE hAckThread = CreateThread(nullptr, 0, receiveAck, this, 0, nullptr);
        uint32_t temp = base;
        while (base < temp + totalPackets) {
            if (resend.load()) {
                continue;
            }
            // 发送窗口内的数据
            if (nextSeq < base + cwnd && nextSeq < temp + totalPackets) {
                sendMsg.clean();
                size_t offset = (nextSeq - temp) * MAX_MSG_SIZE;
                size_t dataSize = min(MAX_MSG_SIZE, fileSize - offset);
                memcpy(sendMsg.data, fileBuffer.data() + offset, dataSize);
                sendMsg.length = dataSize;
                sendMsg.seqNum = nextSeq;
                setMsg(sendMsg);
                {
                    lock_guard<mutex> lock(bufferMtx);
                    sendBuffer.push_back(sendMsg);
                }
                printMessageInfo(sendMsg, "发送报文：", SEND);
                sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, sizeof(SOCKADDR_IN));
                // 第一个包启动计时器
                if (nextSeq == base) {
                    timerStart.store(GetTickCount64());
                }
                nextSeq++;
            }
        }
        // 清理线程
        running.store(false);
        if (hAckThread != nullptr) {
            WaitForSingleObject(hAckThread, INFINITE);
            CloseHandle(hAckThread);
        }
        // 计算传输统计
        auto duration = chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now() - startTime).count();
        float throughput = duration > 0 ? static_cast<float>(fileSize) / duration : 0.0f;
        print("传输完成:\n总传输时间: " + to_string(duration) + " ms\n平均吞吐率: " + to_string(throughput) + " bytes/ms", INFO);
    }
    catch (const exception& e) {
        print("文件传输错误: " + string(e.what()), ERR);
    }
}

//实现三次握手
bool Client::threeWayHandshake() {
    int AddrLen = sizeof(routerAddr);
    // 发送第一次握手（SYN有效）
    sendMsg.clean();
    sendMsg.set_SYN();
    sendMsg.seqNum = nextSeq++;
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送第一次握手：", SEND);
    sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    // 接收第二次握手（SYN、ACK有效）
    for (int retry = 0; retry < MAX_SEND_TIMES; ++retry) {
        clock_t start = clock();
        while (clock() - start < MAX_WAIT_TIME) {
            recvMsg.clean();
            int recvByte = recvfrom(clientSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &AddrLen);
            if (recvByte > 0 && recvMsg.checkSum()) {
                if (recvMsg.is_SYN() && recvMsg.is_ACK() && recvMsg.ackNum == sendMsg.seqNum + 1) {
                    print("接收第二次握手成功", INFO);
                    // 发送第三次握手（ACK有效）
                    sendMsg.clean();
                    sendMsg.set_ACK();
                    sendMsg.ackNum = recvMsg.seqNum + 1;
                    setMsg(sendMsg);
                    printMessageInfo(sendMsg, "发送第三次握手：", SEND);
                    sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
                    // 等待确认第三次握手成功
                    clock_t confirmStart = clock();
                    print("等待 2MSL 的时间", INFO);
                    while (clock() - confirmStart < 2 * MAX_WAIT_TIME) {
                        recvMsg.clean();
                        recvByte = recvfrom(clientSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &AddrLen);
                        if (recvByte > 0 && recvMsg.checkSum()) {
                            if (recvMsg.is_SYN() && recvMsg.is_ACK()) {
                                print("第三次握手可能丢失，重传", WARN);
                                sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
                            }
                        }
                    }
                    isConnected = true;
                    return true;
                }
                else {
                    print("接收到错误数据", WARN);
                }
            }
        }
        print("接收第二次握手超时，重新发送第一次握手", WARN);
        printMessageInfo(sendMsg, "重新发送第一次握手：", SEND);
        sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    }
    print("三次握手失败", ERR);
    return false;
}

//实现四次挥手
bool Client::fourWayHandwave() {
    int AddrLen = sizeof(routerAddr);
    // 发送第一次挥手（FIN有效）
    sendMsg.clean();
    sendMsg.set_FIN();
    sendMsg.seqNum = nextSeq++;
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送第一次挥手：", SEND);
    sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    // 接收第二次挥手（ACK有效）
    for (int retry = 0; retry < MAX_SEND_TIMES; ++retry) {
        clock_t start = clock();
        while (clock() - start < MAX_WAIT_TIME) {
            recvMsg.clean();
            int recvByte = recvfrom(clientSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &AddrLen);
            if (recvByte > 0 && recvMsg.checkSum()) {
                if (recvMsg.is_ACK() && recvMsg.ackNum == sendMsg.seqNum + 1) {
                    print("接收第二次挥手成功", INFO);
                    // 等待第三次挥手（FIN有效）
                    clock_t waitStart = clock();
                    while (clock() - waitStart < MAX_WAIT_TIME) {
                        recvMsg.clean();
                        recvByte = recvfrom(clientSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &AddrLen);
                        if (recvByte > 0 && recvMsg.checkSum()) {
                            if (recvMsg.is_FIN()) {
                                print("接收第三次挥手成功", INFO);
                                // 发送第四次挥手（ACK有效）
                                sendMsg.clean();
                                sendMsg.set_ACK();
                                sendMsg.ackNum = recvMsg.seqNum + 1;
                                setMsg(sendMsg);
                                printMessageInfo(sendMsg, "发送第四次挥手：", SEND);
                                sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
                                return true;
                            }
                            else {
                                print("接收到错误数据", WARN);
                            }
                        }
                    }
                }
                else {
                    print("接收到错误数据", WARN);
                }
            }
        }
        print("接收超时，重新发送第一次挥手", WARN);
        sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    }
    print("四次挥手失败", ERR);
    return false;
}

// 等待退出
void Client::waitExit() {
    print("等待 2MSL 的时间", INFO);
    int addrLen = sizeof(routerAddr);
    auto start = chrono::steady_clock::now();
    while (chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now() - start).count() < 2 * MAX_WAIT_TIME) {
        int recvByte = recvfrom(clientSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &addrLen);
        if (recvByte > 0 && recvMsg.checkSum()) {
            //发送第四次挥手（ACK有效）
            sendtoWithSimulation(clientSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
        }
    }
}

// 运行客户端
void Client::run() {
    if (initialize()) {
        while (!threeWayHandshake()) {
            print("连接失败，进行下一次尝试", ERR);
        }
        while (true) {
            print("[Client] 请选择操作: 1.发送文件 2.退出", INFO);
            int choose = 0;
            // 添加输入验证
            if (!(cin >> choose)) {
                cin.clear(); // 清除错误标志
                cin.ignore((numeric_limits<streamsize>::max)(), '\n'); // 清除输入缓冲区
                print("输入错误，请输入数字", WARN);
                continue;
            }
            string filepath;
            switch (choose) {
            case 1:
                print("请输入要发送的文件路径：", INFO);
                cin >> filepath;
                sendFile(filepath);
                break;
            case 2:
                print("Client 将断开连接", INFO);
                if (fourWayHandwave()) {
                    waitExit();
                    return;
                }
                print("Client 断开连接失败", ERR);
                break;
            default:
                print("输入错误，请输入 1 或 2", WARN);
                cin.ignore((numeric_limits<streamsize>::max)(), '\n'); // 清除输入缓冲区
                break;
            }
        }
    }
}

int main() {
    Client client;
    client.run();
    system("pause");
    return 0;
}