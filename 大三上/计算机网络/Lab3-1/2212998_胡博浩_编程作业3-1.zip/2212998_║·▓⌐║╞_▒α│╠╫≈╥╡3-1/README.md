**注意**：

1. 需要把整个测试文件的文件夹和 Client.exe 放在同一目录下，运行时输入类似（1.jpg）即可传输
2. 代码使用 visual studio 编写，文件编码为 UTF-8(BOM)，C++语言标准为默认(ISO C++14 标准)，如果想要编译运行最好还是使用最新版的 visual studio……

