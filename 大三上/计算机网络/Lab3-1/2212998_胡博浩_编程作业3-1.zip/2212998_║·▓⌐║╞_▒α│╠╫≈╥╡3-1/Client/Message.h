﻿using namespace std;

// 模拟丢包
double packetLossRate = 0.05; // 丢包率，取值范围为 0.0 到 1.0
int delayTime = 100;         // 延时时间，单位为毫秒

// 常量定义
constexpr int MAX_WAIT_TIME = 500;        // 超时时间（毫秒）
constexpr int MAX_SEND_TIMES = 10;       // 最大重传次数
constexpr int MAX_FILE_SIZE = 100000000; // 最大文件大小（字节）
constexpr int MAX_MSG_SIZE = 10000;      // 最大数据段大小

// 网络配置常量
constexpr const char* routerIP = "127.0.0.1";   // 路由器 IP 地址
constexpr const char* clientIP = "127.0.0.1";   // 客户端 IP 地址
constexpr const int routerPORT = 66666;         // 路由器端口
constexpr const int clientPORT = 77777;         // 客户端端口

//标志位定义
struct Flag {
    static constexpr uint16_t SYN = 0x1;        // 0001,建立连接
    static constexpr uint16_t ACK = 0x2;        // 0010,确认接收
    static constexpr uint16_t FIN = 0x4;        // 0100,关闭连接
    static constexpr uint16_t FILE_NAME = 0x8;  // 1000,文件名
};

//修改编译器默认的数据成员对齐方式，为1字节，确保所有的成员都会紧密排列
#pragma pack(1)
class Message {
public:
    //头部（一共28字节）
    uint32_t srcIP{ 0 };     // 源IP(4字节)
    uint32_t destIP{ 0 };    // 目的IP(4字节)
    uint16_t srcPort{ 0 };   // 源端口(2字节)
    uint16_t destPort{ 0 };  // 目的端口(2字节)
    uint32_t seqNum{ 0 };    // 序号(4字节)，这个表示相对序列号
    uint32_t ackNum{ 0 };    // 确认号(4字节)
    uint32_t length{ 0 };    // 数据段长度(4字节)
    uint16_t flags{ 0 };     // 标志位(2字节)
    uint16_t checkNum{ 0 };  // 校验和(2字节)

    uint8_t data[MAX_MSG_SIZE]{ 0 };  // 数据段

    Message() = default;

    // 标志位管理
    bool is_SYN() const { return flags & Flag::SYN; }
    void set_SYN() { flags |= Flag::SYN; }
    bool is_ACK() const { return flags & Flag::ACK; }
    void set_ACK() { flags |= Flag::ACK; }
    bool is_FIN() const { return flags & Flag::FIN; }
    void set_FIN() { flags |= Flag::FIN; }
    bool is_FILE_NAME() const { return flags & Flag::FILE_NAME; }
    void set_FILE_NAME() { flags |= Flag::FILE_NAME; }

    // 校验和方法
    bool checkSum();
    void setCheckSum();

    // 清理报文
    void clean() {
        srcIP = destIP = srcPort = destPort = seqNum = ackNum = length = flags = checkNum = 0;
        memset(data, 0, sizeof(data));
    }
};
#pragma pack()//恢复到编译器默认的对齐方式

//验证Message结构体的校验和是否正确
bool Message::checkSum()
{
    uint32_t sum = 0;
    uint16_t* msg = (uint16_t*)this;

    for (int i = 0; i < sizeof(*this) / 2; i++)
    {
        sum += *msg++;
        if (sum & 0xFFFF0000)
        {
            sum &= 0xFFFF;
            sum++;
        }
    }

    return (sum & 0xFFFF) == 0xFFFF;
}

//计算并设置Message结构体的校验和
void Message::setCheckSum()
{
    checkNum = 0;
    uint32_t sum = 0;
    uint16_t* msg = (uint16_t*)this;

    for (int i = 0; i < sizeof(*this) / 2; i++)
    {
        sum += *msg++;
        if (sum & 0xFFFF0000)
        {
            sum &= 0xFFFF;
            sum++;
        }
    }
    checkNum = ~(sum & 0xFFFF);
}
