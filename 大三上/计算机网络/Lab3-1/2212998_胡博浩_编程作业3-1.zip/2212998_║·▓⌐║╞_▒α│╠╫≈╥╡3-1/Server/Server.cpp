﻿#include <chrono>
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <thread>
#include <vector>
#include <ws2tcpip.h>
#include "Message.h"
#pragma comment (lib, "ws2_32.lib")
using namespace std;

enum Level { INFO, WARN, ERR, RECV, SEND, NOP };

class Server {
private:
    SOCKET serverSocket;//服务器socket
    SOCKADDR_IN serverAddr;//服务器地址
    SOCKADDR_IN routerAddr;//路由器地址
    bool isConnected;//是否连接成功
    int currentSeq;  // 当前序列号
    Message sendMsg;//发送的报文
    Message recvMsg;//接收的报文

    void printMessageInfo(const Message& msg, const string& prefix, Level level);//打印报文信息
    string getErrorMessage(int errorCode);//获取系统错误信息
    void setMsg(Message& sendMsg);//设置报文
    bool recvMessage(Message& recvMsg);//实现单个报文接收
    void sendAck(uint32_t ackNum);//发送ACK报文
    bool sendtoWithSimulation(SOCKET s, const char* buf, int len, int flags, const struct sockaddr* to, int tolen);//发送数据时模拟丢包延时
public:
    Server() : serverSocket(INVALID_SOCKET), isConnected(false), currentSeq(0) {}
    ~Server() {
        if (serverSocket != INVALID_SOCKET) {
            closesocket(serverSocket);
            serverSocket = INVALID_SOCKET;
        }
        WSACleanup();
    }
    void print(const string& info, Level level);//打印信息
    bool initialize();//初始化server
    bool threeWayHandshake();//实现server的三次握手
    void recvFile();//实现文件接收
    bool fourWayHandwave();//实现server的四次挥手
    void run();//运行server
};

// 打印信息
void Server::print(const string& info, Level level) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    switch (level) {
    case Level::INFO:
        SetConsoleTextAttribute(hConsole, 7); // 白色
        break;
    case Level::WARN:
        SetConsoleTextAttribute(hConsole, 14); // 黄色
        break;
    case Level::ERR:
        SetConsoleTextAttribute(hConsole, 12); // 红色
        break;
    case Level::RECV:
        SetConsoleTextAttribute(hConsole, 11); // 青色
        break;
    case Level::SEND:
        SetConsoleTextAttribute(hConsole, 10); // 绿色
        break;
    default:
        SetConsoleTextAttribute(hConsole, 7); // 默认颜色
        break;
    }
    cout << info << endl;
    SetConsoleTextAttribute(hConsole, 7); // 恢复默认颜色
}

// 打印报文信息
void Server::printMessageInfo(const Message& msg, const string& prefix, Level level) {
    ostringstream oss;
    oss << prefix
        << "序列号: " << msg.seqNum
        << ", 确认号: " << msg.ackNum
        << ", 标志位: ";
    if (msg.is_SYN()) oss << "[SYN] ";
    if (msg.is_ACK()) oss << "[ACK] ";
    if (msg.is_FIN()) oss << "[FIN] ";
    if (msg.is_FILE_NAME()) oss << "[FILE_NAME] ";
    oss << ", 校验和: " << msg.checkNum;
    print(oss.str(), level);
}

// 获取系统错误信息
string Server::getErrorMessage(int errorCode) {
    char errMsg[512];
    DWORD result = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, errorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        errMsg, sizeof(errMsg), NULL);
    return result ? string(errMsg) : "未知错误。";
}

//发送数据时模拟丢包延时
bool Server::sendtoWithSimulation(SOCKET s, const char* buf, int len, int flags, const struct sockaddr* to, int tolen) {
    // 模拟延时
    std::this_thread::sleep_for(std::chrono::milliseconds(delayTime));
    // 模拟丢包
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_real_distribution<> dis(0.0, 1.0);
    if (dis(gen) >= packetLossRate) {
        sendto(s, buf, len, flags, to, tolen);// 实际发送数据
        return true;
    }
    else {
        print("模拟丢包", WARN);
        return false;
    }
}

void Server::setMsg(Message& sendMsg) {
    sendMsg.srcPort = serverPORT;
    sendMsg.destPort = routerPORT;
    sendMsg.seqNum = currentSeq++;
    sendMsg.setCheckSum();
}

//初始化server
bool Server::initialize() {
    //初始化 Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        print("Winsock 初始化失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("Winsock 初始化成功", INFO);
    // 创建服务端套接字, 使用 UDP 协议
    serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (serverSocket == INVALID_SOCKET) {
        print("创建socket失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    // 设置套接字为非阻塞模式
    u_long mode = 1;
    if (ioctlsocket(serverSocket, FIONBIO, &mode) != 0) {
        print("无法设置socket为非阻塞模式: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("创建socket成功", INFO);
    // 初始化路由器地址
    routerAddr.sin_family = AF_INET;//使用IPv4地址
    routerAddr.sin_port = htons(routerPORT);
    inet_pton(AF_INET, routerIP, &routerAddr.sin_addr);
    // 初始化服务器地址
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPORT);
    inet_pton(AF_INET, serverIP, &serverAddr.sin_addr);
    // 绑定服务器地址
    if (bind(serverSocket, (LPSOCKADDR)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        print("绑定服务器地址失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("绑定服务器地址成功", INFO);
    return true;
}

//实现server的三次握手
bool Server::threeWayHandshake() {
    int addrLen = sizeof(routerAddr);
    // 发送第二次握手的消息（SYN、ACK有效）
    sendMsg.clean();
    sendMsg.set_SYN();
    sendMsg.set_ACK();
    sendMsg.ackNum = recvMsg.seqNum + 1;
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送第二次握手：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
    // 接收第三次握手的消息（ACK有效）
    for (int retry = 0; retry < MAX_SEND_TIMES; ++retry) {
        clock_t start = clock();
        while (clock() - start < MAX_WAIT_TIME) {
            recvMsg.clean();
            int recvByte = recvfrom(serverSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &addrLen);
            if (recvByte > 0) {
                if (recvMsg.checkSum()) {
                    if (recvMsg.is_ACK() && recvMsg.ackNum == sendMsg.seqNum + 1) {
                        print("接收第三次握手成功", INFO);
                        isConnected = true;
                        return true;
                    }
                    else {
                        print("[重复接收报文] server收到第一次握手的报文，并发送第二次握手的报文", WARN);
                        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
                    }
                }
                else {
                    print("接收到错误数据", WARN);
                }
            }
        }
        print("接收第三次握手等待超时，重新发送第二次握手", WARN);
        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
    }
    print("接收第三次握手失败", ERR);
    return false;
}

//实现单个报文接收
bool Server::recvMessage(Message& msg) {
    int addrLen = sizeof(routerAddr);
    while (true) {
        msg.clean();
        int recvBytes = recvfrom(serverSocket, (char*)&msg, sizeof(msg), 0, (sockaddr*)&routerAddr, &addrLen);
        if (recvBytes > 0) {
            if (msg.checkSum()) {
                if (msg.seqNum == sendMsg.ackNum) {
                    print("Server收到：seq = " + to_string(msg.seqNum) + " 的数据报文", RECV);
                    return true;
                }
                else {
                    // 处理重复数据包
                    print("[重复接收报文] server收到 seq = " + to_string(msg.seqNum) + " 的数据报文，并发送 ack = " + to_string(sendMsg.ackNum) + " 的ACK报文", WARN);
                    sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
                }
            }
            else {
                print("接收到错误数据", ERR);
            }
        }
    }
    return false;
}

//实现文件接收
void Server::recvFile() {
    try {
        // 接收文件信息
        std::string fileName(reinterpret_cast<char*>(recvMsg.data));
        uint32_t fileSize = recvMsg.length;
        print("接收文件: " + fileName + " (" + to_string(fileSize) + " bytes)", RECV);
        // 发送 ACK 报文
        sendAck(recvMsg.seqNum + 1);
        // 准备接收文件数据
        std::vector<BYTE> fileBuffer;
        fileBuffer.reserve(fileSize);
        // 接收文件数据
        uint32_t receivedBytes = 0;
        auto startTime = chrono::steady_clock::now();
        while (receivedBytes < fileSize) {
            if (!recvMessage(recvMsg)) {
                throw std::runtime_error("数据包接收失败");
            }
            uint32_t dataSize = min(fileSize - receivedBytes, static_cast<uint32_t>(MAX_MSG_SIZE));
            fileBuffer.insert(fileBuffer.end(), recvMsg.data, recvMsg.data + dataSize);
            receivedBytes += dataSize;
            // 发送 ACK 报文
            sendAck(recvMsg.seqNum + 1);
        }
        auto endTime = chrono::steady_clock::now();
        auto duration = chrono::duration_cast<chrono::milliseconds>(endTime - startTime).count();
        // 写入文件
        std::ofstream outFile(fileName, std::ios::binary);
        if (!outFile) {
            throw std::runtime_error("无法创建输出文件");
        }
        outFile.write(reinterpret_cast<char*>(fileBuffer.data()), fileBuffer.size());
        print("文件接收完成", INFO);
        // 记录传输统计
        float throughput = duration > 0 ? static_cast<float>(fileSize) / duration : 0.0f;
        print("传输统计:\n总接收时间: " + to_string(duration) + " ms\n平均吞吐率: " + to_string(throughput) + " bytes/ms", INFO);
    }
    catch (const std::exception& e) {
        print("文件接收错误: " + string(e.what()), ERR);
    }
}

//发送ACK报文
void Server::sendAck(uint32_t ackNum) {
    sendMsg.clean();
    sendMsg.set_ACK();
    sendMsg.ackNum = ackNum;
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送ACK报文：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, sizeof(SOCKADDR_IN));
    cout << endl;
}

//实现server的四次挥手
bool Server::fourWayHandwave() {
    int AddrLen = sizeof(routerAddr);
    //发送第二次挥手的消息（ACK有效）
    Message ackMsg;
    ackMsg.set_ACK();
    ackMsg.ackNum = recvMsg.seqNum + 1;
    setMsg(ackMsg);
    printMessageInfo(ackMsg, "发送第二次挥手：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&ackMsg, sizeof(ackMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    //发送第三次挥手的消息（FIN有效）
    sendMsg.clean();
    sendMsg.set_FIN();
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送第三次挥手：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    // 接收第四次挥手的消息（ACK有效）
    for (int retry = 0; retry < MAX_SEND_TIMES; ++retry) {
        clock_t start = clock();
        while (clock() - start < MAX_WAIT_TIME) {
            recvMsg.clean();
            int recvByte = recvfrom(serverSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &AddrLen);
            if (recvByte > 0) {
                if (recvMsg.checkSum()) {
                    if (recvMsg.is_ACK() && recvMsg.ackNum == sendMsg.seqNum + 1) {
                        print("接收第四次挥手成功", INFO);
                        return true;
                    }
                    else {
                        print("[重复接收报文] server收到第一次挥手的报文，并发送第二、三次挥手的报文", WARN);
                        sendtoWithSimulation(serverSocket, (char*)&ackMsg, sizeof(ackMsg), 0, (sockaddr*)&routerAddr, AddrLen);
                        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
                    }
                }
                else {
                    print("接收到错误数据", ERR);
                }
            }
        }
        print("接收第四次挥手等待超时，发送第二、三次挥手的报文", WARN);
        sendtoWithSimulation(serverSocket, (char*)&ackMsg, sizeof(ackMsg), 0, (sockaddr*)&routerAddr, AddrLen);
        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    }
    print("接收第四次挥手失败", ERR);
    return false;
}

void Server::run() {
    if (initialize()) {
        while (true) {
            recvMsg.clean();
            int addrLen = sizeof(routerAddr);
            int recvBytes = recvfrom(serverSocket, (char*)&recvMsg, sizeof(recvMsg),
                0, (sockaddr*)&routerAddr, &addrLen);
            if (recvBytes > 0) {
                if (recvMsg.checkSum()) {
                    if (recvMsg.is_SYN()) {
                        //接收第一次握手的消息（SYN有效）
                        print("接收第一次握手成功", INFO);
                        if (threeWayHandshake()) {
                            print("三次握手成功", INFO);
                        }
                        else {
                            print("三次握手失败", ERR);
                        }
                    }
                    else if (recvMsg.is_FIN()) {
                        //接收第一次挥手的消息（FIN有效）
                        print("接收第一次挥手成功", INFO);
                        if (fourWayHandwave()) {
                            print("四次挥手成功", INFO);
                            break;
                        }
                        else {
                            print("四次挥手失败", ERR);
                        }
                    }
                    else if (recvMsg.is_FILE_NAME()) {
                        recvFile();
                    }
                    else {
                        print("接收到错误数据", WARN);
                    }
                }
                else {
                    print("接收到错误数据", WARN);
                }
            }
        }
    }
}

int main() {
    Server server;
    server.run();
    system("pause");
    return 0;
}