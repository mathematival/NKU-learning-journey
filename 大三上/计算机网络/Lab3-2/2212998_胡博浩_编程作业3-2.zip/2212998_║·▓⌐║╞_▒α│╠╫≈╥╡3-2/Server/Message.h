﻿#pragma once
#include <iostream>
#include <string>
#include <random>
#include <chrono>
#include <thread>
#include <cstring>
#include <sstream>
#include <winsock2.h>
using namespace std;

// 模拟丢包
constexpr double PACKET_LOSS_RATE = 0.05; // 丢包率（0.0 - 1.0）
constexpr int DELAY_TIME = 10;           // 延时时间（毫秒）

// 常量定义
constexpr int MAX_WAIT_TIME = 50;        // 超时时间（毫秒）
constexpr int MAX_SEND_TIMES = 10;        // 最大重传次数
constexpr int MAX_FILE_SIZE = 100000000;  // 最大文件大小（字节）
constexpr int MAX_MSG_SIZE = 10000;       // 最大数据段大小

// 网络配置常量
constexpr const char* routerIP = "127.0.0.1";  // 路由器 IP 地址
constexpr const char* clientIP = "127.0.0.1";  // 客户端 IP 地址
constexpr const char* serverIP = "127.0.0.1";  // 服务器 IP 地址
constexpr int routerPORT = 77777;              // 路由器端口
constexpr int serverPORT = 66666;              // 服务器端口

// 标志位定义
struct Flag {
    static constexpr uint16_t SYN = 0x1;        // 建立连接
    static constexpr uint16_t ACK = 0x2;        // 确认接收
    static constexpr uint16_t FIN = 0x4;        // 关闭连接
    static constexpr uint16_t FILE_NAME = 0x8;  // 文件名
};

// 修改编译器默认的数据成员对齐方式，为1字节，确保所有的成员都会紧密排列
#pragma pack(1)
class Message {
public:
    // 头部（共28字节）
    uint32_t srcIP{ 0 };     // 源IP(4字节)
    uint32_t destIP{ 0 };    // 目的IP(4字节)
    uint16_t srcPort{ 0 };   // 源端口(2字节)
    uint16_t destPort{ 0 };  // 目的端口(2字节)
    uint32_t seqNum{ 0 };    // 序号(4字节)
    uint32_t ackNum{ 0 };    // 确认号(4字节)
    uint32_t length{ 0 };    // 数据段长度(4字节)
    uint16_t flags{ 0 };     // 标志位(2字节)
    uint16_t checkNum{ 0 };  // 校验和(2字节)

    uint8_t data[MAX_MSG_SIZE]{ 0 };  // 数据段

    Message() = default;

    // 标志位管理
    bool is_SYN() const { return flags & Flag::SYN; }
    void set_SYN() { flags |= Flag::SYN; }
    bool is_ACK() const { return flags & Flag::ACK; }
    void set_ACK() { flags |= Flag::ACK; }
    bool is_FIN() const { return flags & Flag::FIN; }
    void set_FIN() { flags |= Flag::FIN; }
    bool is_FILE_NAME() const { return flags & Flag::FILE_NAME; }
    void set_FILE_NAME() { flags |= Flag::FILE_NAME; }

    // 校验和方法
    bool checkSum();
    void setCheckSum();

    // 清理报文
    void clean() {
        srcIP = destIP = srcPort = destPort = seqNum = ackNum = length = flags = checkNum = 0;
        memset(data, 0, sizeof(data));
    }
};
#pragma pack()  // 恢复默认的对齐方式

// 验证Message结构体的校验和是否正确
bool Message::checkSum() {
    uint32_t sum = 0;
    uint16_t* msg = (uint16_t*)this;
    size_t size = sizeof(Message) / 2;

    for (size_t i = 0; i < size; ++i) {
        sum += *msg++;
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    return (sum & 0xFFFF) == 0xFFFF;
}

// 计算并设置Message结构体的校验和
void Message::setCheckSum() {
    checkNum = 0;
    uint32_t sum = 0;
    uint16_t* msg = (uint16_t*)this;
    size_t size = sizeof(Message) / 2;

    for (size_t i = 0; i < size; ++i) {
        sum += *msg++;
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    checkNum = ~sum;
}

// 日志级别
enum Level { INFO, WARN, ERR, RECV, SEND };

class UDP {
public:
    bool isConnected;                   // 是否连接成功
    Message sendMsg;                    // 发送的报文
    Message recvMsg;                    // 接收的报文

    string getErrorMessage(int errorCode);  // 获取系统错误信息
    void print(const string& info, Level level);  // 打印信息
    void printMessageInfo(const Message& msg, const string& prefix, Level level);  // 打印报文信息
    bool sendtoWithSimulation(SOCKET s, const char* buf, int len, int flags, const sockaddr* to, int tolen);  // 发送数据时模拟丢包延时
};

// 获取系统错误信息
string UDP::getErrorMessage(int errorCode) {
    char errMsg[512];
    DWORD result = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, errorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        errMsg, sizeof(errMsg), NULL);
    return result ? string(errMsg) : "未知错误。";
}

// 打印信息
void UDP::print(const string& info, Level level) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    WORD color = 7;// 默认白色
    switch (level) {
    case INFO:
        color = 7;// 白色
        break;
    case WARN:
        color = 14;// 黄色
        break;
    case ERR:
        color = 12;// 红色
        break;
    case RECV:
        color = 11;// 青色
        break;
    case SEND:
        color = 10;// 绿色
        break;
    default:
        break;
    }
    SetConsoleTextAttribute(hConsole, color);
    cout << info << endl;
    SetConsoleTextAttribute(hConsole, 7);
}

// 打印报文信息
void UDP::printMessageInfo(const Message& msg, const string& prefix, Level level) {
    ostringstream oss;
    oss << prefix
        << "序列号: " << msg.seqNum
        << ", 确认号: " << msg.ackNum
        << ", 标志位: ";
    if (msg.is_SYN()) oss << "[SYN] ";
    if (msg.is_ACK()) oss << "[ACK] ";
    if (msg.is_FIN()) oss << "[FIN] ";
    if (msg.is_FILE_NAME()) oss << "[FILE_NAME] ";
    oss << ", 校验和: " << msg.checkNum;
    print(oss.str(), level);
}

// 发送数据时模拟丢包延时
bool UDP::sendtoWithSimulation(SOCKET s, const char* buf, int len, int flags, const sockaddr* to, int tolen) {
    this_thread::sleep_for(chrono::milliseconds(DELAY_TIME));
    static random_device rd;
    static mt19937 gen(rd());
    static uniform_real_distribution<> dis(0.0, 1.0);
    if (dis(gen) >= PACKET_LOSS_RATE) {
        sendto(s, buf, len, flags, to, tolen);
        return true;
    }
    else {
        print("模拟丢包", WARN);
        return false;
    }
}
