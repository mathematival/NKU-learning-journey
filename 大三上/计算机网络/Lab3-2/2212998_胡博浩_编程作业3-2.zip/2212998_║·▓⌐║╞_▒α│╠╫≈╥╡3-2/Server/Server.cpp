﻿#include "Message.h"
#include <fstream>
#include <iostream>
#include <thread>
#include <vector>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

class Server : UDP {
private:
    SOCKET serverSocket;                 // 服务器 socket
    SOCKADDR_IN serverAddr;              // 服务器地址
    SOCKADDR_IN routerAddr;              // 路由器地址

    uint32_t windowSize;                 // 窗口大小
    uint32_t nextSeq;                    // 下一个序列号
    uint32_t base;                       // 窗口基序号

    void printWindowStatus();            // 窗口信息打印函数
    void setMsg(Message& msg);           // 设置报文
    bool recvMessage(Message& msg);      // 实现单个报文接收
    void sendAck(uint32_t ackNum);       // 发送ACK报文
public:
    Server() : serverSocket(INVALID_SOCKET) {
        isConnected = false; nextSeq = 0; base = 0; windowSize = 1;
    }
    ~Server() {
        if (serverSocket != INVALID_SOCKET) {
            closesocket(serverSocket);
            serverSocket = INVALID_SOCKET;
        }
        WSACleanup();
    }
    bool initialize();                   // 初始化服务器
    bool threeWayHandshake();            // 实现三次握手
    void recvFile();                     // 实现文件接收
    bool fourWayHandwave();              // 实现四次挥手
    void run();                          // 运行服务器
};

// 初始化服务器
bool Server::initialize() {
    //初始化 Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        print("Winsock 初始化失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("Winsock 初始化成功", INFO);
    // 创建服务端套接字, 使用 UDP 协议
    serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (serverSocket == INVALID_SOCKET) {
        print("创建socket失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    // 设置套接字为非阻塞模式
    u_long mode = 1;
    if (ioctlsocket(serverSocket, FIONBIO, &mode) != 0) {
        print("无法设置socket为非阻塞模式: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("创建socket成功", INFO);
    // 初始化路由器地址
    routerAddr.sin_family = AF_INET;//使用IPv4地址
    routerAddr.sin_port = htons(routerPORT);
    inet_pton(AF_INET, routerIP, &routerAddr.sin_addr);
    // 初始化服务器地址
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPORT);
    inet_pton(AF_INET, serverIP, &serverAddr.sin_addr);
    // 绑定服务器地址
    if (bind(serverSocket, (LPSOCKADDR)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        print("绑定服务器地址失败: " + getErrorMessage(WSAGetLastError()), ERR);
        return false;
    }
    print("绑定服务器地址成功", INFO);
    return true;
}

// 设置报文
void Server::setMsg(Message& sendMsg) {
    sendMsg.srcPort = serverPORT;
    sendMsg.destPort = routerPORT;
    sendMsg.setCheckSum();
}

// 窗口信息打印函数
void Server::printWindowStatus() {
    print("接收窗口状态：base=" + to_string(base) + ", 窗口大小=" + to_string(windowSize), INFO);
}

//实现单个报文接收
bool Server::recvMessage(Message& msg) {
    int addrLen = sizeof(routerAddr);
    while (true) {
        msg.clean();
        int recvBytes = recvfrom(serverSocket, (char*)&msg, sizeof(msg), 0, (sockaddr*)&routerAddr, &addrLen);
        if (recvBytes > 0) {
            if (msg.checkSum()) {
                if (msg.seqNum == base) {
                    print("Server收到期望的报文：seq = " + to_string(msg.seqNum), RECV);
                    base++;
                    sendAck(base);
                    return true;
                }
                else if (msg.seqNum < base) {
                    // 发送上次的ACK，告知已接收
                    print("收到重复报文：seq = " + to_string(msg.seqNum), WARN);
                    sendAck(base);
                }
                else {
                    // 序号大于期望值，直接丢弃并发送ACK
                    print("收到超出期望的报文：seq = " + to_string(msg.seqNum), WARN);
                    sendAck(base);
                }
            }
            else {
                print("接收到校验和错误的报文", ERR);
            }
        }
    }
    return false;
}

//发送ACK报文
void Server::sendAck(uint32_t ackNum) {
    sendMsg.clean();
    sendMsg.set_ACK();
    sendMsg.ackNum = ackNum;
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送ACK报文：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, sizeof(SOCKADDR_IN));
    cout << endl;
}

// 实现文件接收
void Server::recvFile() {
    try {
        // 接收文件信息
        string fileName((char*)recvMsg.data);
        uint32_t fileSize = recvMsg.length;
        print("开始接收文件：" + fileName + "，大小：" + to_string(fileSize) + " bytes", INFO);
        base = recvMsg.seqNum + 1;
        sendAck(recvMsg.seqNum + 1);// 发送 ACK 报文
        // 接收文件数据
        vector<uint8_t> fileBuffer;
        fileBuffer.reserve(fileSize);
        auto startTime = chrono::steady_clock::now();
        while (fileBuffer.size() < fileSize) {
            if (recvMessage(recvMsg)) {
                size_t dataLen = recvMsg.length;
                fileBuffer.insert(fileBuffer.end(), recvMsg.data, recvMsg.data + dataLen);
            }
        }
        auto duration = chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now() - startTime).count();
        // 写入文件
        ofstream outFile(fileName, std::ios::binary);
        if (!outFile) {
            throw std::runtime_error("无法创建输出文件");
        }
        outFile.write((char*)fileBuffer.data(), fileBuffer.size());
        outFile.close();
        // 计算传输统计
        float throughput = duration > 0 ? static_cast<float>(fileSize) / duration : 0.0f;
        print("文件接收完成:\n总传输时间: " + to_string(duration) + " ms\n平均吞吐率: " + to_string(throughput) + " bytes/ms", INFO);
    }
    catch (const exception& e) {
        print("文件接收错误: " + string(e.what()), ERR);
    }
}

//实现三次握手
bool Server::threeWayHandshake() {
    int addrLen = sizeof(routerAddr);
    // 发送第二次握手的消息（SYN、ACK有效）
    sendMsg.clean();
    sendMsg.set_SYN();
    sendMsg.set_ACK();
    sendMsg.ackNum = recvMsg.seqNum + 1;
    sendMsg.seqNum = nextSeq++;
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送第二次握手：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
    // 接收第三次握手的消息（ACK有效）
    for (int retry = 0; retry < MAX_SEND_TIMES; ++retry) {
        clock_t start = clock();
        while (clock() - start < MAX_WAIT_TIME) {
            recvMsg.clean();
            int recvByte = recvfrom(serverSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &addrLen);
            if (recvByte > 0) {
                if (recvMsg.checkSum()) {
                    if (recvMsg.is_ACK() && recvMsg.ackNum == sendMsg.seqNum + 1) {
                        print("接收第三次握手成功", INFO);
                        isConnected = true;
                        return true;
                    }
                    else {
                        print("[重复接收报文] server收到第一次握手的报文，并发送第二次握手的报文", WARN);
                        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
                    }
                }
                else {
                    print("接收到校验和错误的报文", WARN);
                }
            }
        }
        print("接收第三次握手超时，重传第二次握手", WARN);
        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
    }
    print("接收第三次握手失败", ERR);
    return false;
}

//实现四次挥手
bool Server::fourWayHandwave() {
    int AddrLen = sizeof(routerAddr);
    //发送第二次挥手的消息（ACK有效）
    Message ackMsg;
    ackMsg.set_ACK();
    ackMsg.ackNum = recvMsg.seqNum + 1;
    setMsg(ackMsg);
    printMessageInfo(ackMsg, "发送第二次挥手：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&ackMsg, sizeof(ackMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    //发送第三次挥手的消息（FIN有效）
    sendMsg.clean();
    sendMsg.set_FIN();
    sendMsg.seqNum = nextSeq++;
    setMsg(sendMsg);
    printMessageInfo(sendMsg, "发送第三次挥手：", SEND);
    sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    // 接收第四次挥手的消息（ACK有效）
    for (int retry = 0; retry < MAX_SEND_TIMES; ++retry) {
        clock_t start = clock();
        while (clock() - start < MAX_WAIT_TIME) {
            recvMsg.clean();
            int recvByte = recvfrom(serverSocket, (char*)&recvMsg, sizeof(recvMsg), 0, (sockaddr*)&routerAddr, &AddrLen);
            if (recvByte > 0) {
                if (recvMsg.checkSum()) {
                    if (recvMsg.is_ACK() && recvMsg.ackNum == sendMsg.seqNum + 1) {
                        print("接收第四次挥手成功", INFO);
                        isConnected = false;
                        return true;
                    }
                    else {
                        print("[重复接收报文] server收到第一次挥手的报文，并发送第二、三次挥手的报文", WARN);
                        sendtoWithSimulation(serverSocket, (char*)&ackMsg, sizeof(ackMsg), 0, (sockaddr*)&routerAddr, AddrLen);
                        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
                    }
                }
                else {
                    print("接收到校验和错误的报文", ERR);
                }
            }
        }
        print("接收第四次挥手超时，重传第二、三次挥手", WARN);
        sendtoWithSimulation(serverSocket, (char*)&ackMsg, sizeof(ackMsg), 0, (sockaddr*)&routerAddr, AddrLen);
        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, AddrLen);
    }
    print("接收第四次挥手失败", ERR);
    return false;
}

// 运行服务器
void Server::run() {
    if (initialize()) {
        while (true) {
            recvMsg.clean();
            int addrLen = sizeof(routerAddr);
            int recvBytes = recvfrom(serverSocket, (char*)&recvMsg, sizeof(recvMsg),
                0, (sockaddr*)&routerAddr, &addrLen);
            if (recvBytes > 0) {
                if (recvMsg.checkSum()) {
                    if (recvMsg.is_SYN()) {
                        //接收第一次握手的消息（SYN有效）
                        print("接收第一次握手成功", INFO);
                        if (threeWayHandshake()) {
                            print("三次握手成功", INFO);
                        }
                        else {
                            print("三次握手失败", ERR);
                        }
                    }
                    else if (recvMsg.is_FIN()) {
                        //接收第一次挥手的消息（FIN有效）
                        print("接收第一次挥手成功", INFO);
                        if (fourWayHandwave()) {
                            print("四次挥手成功", INFO);
                            break;
                        }
                        else {
                            print("四次挥手失败", ERR);
                        }
                    }
                    else if (recvMsg.is_FILE_NAME()) {
                        recvFile();
                    }
                    else {
                        print("接收到错误数据", WARN);
                        print("上一次发送的数据包可能丢失，重发", WARN);
                        sendtoWithSimulation(serverSocket, (char*)&sendMsg, sizeof(sendMsg), 0, (sockaddr*)&routerAddr, addrLen);
                    }
                }
                else {
                    print("接收到校验和错误的报文", WARN);
                }
            }
        }
    }
}

int main() {
    Server server;
    server.run();
    system("pause");
    return 0;
}