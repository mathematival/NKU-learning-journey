﻿#include <iostream>
#include <vector>
#include <thread>
#include <map>
#include <fstream>
#include <winsock2.h>
#include <windows.h>
#include <string>
#include <ctime>

#pragma comment(lib, "ws2_32.lib")

// 服务器监听端口号
const int PORT = 8080;

// 消息类型枚举
enum MessageType {
    TEXT,      // 文本消息
    PRIVATE,   // 私聊消息
    SYSTEM,    // 系统消息
    COMMAND    // 命令消息
};

// 消息结构体
struct Message {
    MessageType type;        // 消息类型
    int senderID;            // 发送者ID
    int targetID;            // 目标用户ID
    char nickname[50];       // 发送者昵称
    char content[512];       // 消息内容
    char time[50];           // 消息时间戳
};

// 日志类，负责记录日志
class Logger {
public:
    // 记录日志到文件和控制台
    static void log(const std::string& message) {
        std::time_t now = std::time(nullptr);
        char date[11];
        struct tm timeinfo;
        localtime_s(&timeinfo, &now);
        std::strftime(date, sizeof(date), "%Y-%m-%d", &timeinfo);

        std::ofstream logFile(std::string(date) + "_log.txt", std::ios::app);
        if (logFile.is_open()) {
            logFile << message << std::endl;
        }
        else {
            std::cerr << "无法打开日志文件。" << std::endl;
        }
        std::cout << message << std::endl;
    }
};

// 聊天服务器类
class ChatServer {
private:
    bool isRunning;                                 // 服务器运行标志
    int nextClientID;                               // 下一个客户端的ID
    std::map<int, std::string> clientNicknames;     // 客户端昵称映射
    std::map<std::string, std::string> userCredentials; // 用户凭证 (用户名:密码)
    std::vector<std::pair<SOCKET, int>> clients;    // 客户端套接字和ID的映射
    SOCKET serverSocket;                            // 服务器套接字

    // 获取系统错误信息
    std::string getErrorMessage(int errorCode);

    // 处理客户端
    void handleClient(SOCKET clientSocket);

    // 发送消息
    void sendMessage(const Message& msg);

    // 广播消息给所有客户端
    void broadcastMessage(const Message& msg, int senderID);

    // 处理服务器命令
    void handleServerCommands();

    // 处理客户端命令
    void handleClientCommands(const Message& msg, int senderID);

    // 清理资源
    void cleanup();

public:
    ChatServer() : serverSocket(INVALID_SOCKET), isRunning(false), nextClientID(1) {
        // 初始化用户凭证
        userCredentials["user1"] = "pass1";
        userCredentials["user2"] = "pass2";
        userCredentials["user3"] = "pass3";
    }
    ~ChatServer() { cleanup(); }

    // 初始化服务器
    bool initialize();

    // 运行服务器
    void run();
};

// 获取系统错误信息
std::string ChatServer::getErrorMessage(int errorCode) {
    char errMsg[512];
    DWORD result = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, errorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        errMsg, sizeof(errMsg), NULL);
    return result ? std::string(errMsg) : "未知错误。";
}

// 处理客户端连接
void ChatServer::handleClient(SOCKET clientSocket) {
    char username[50], password[50];
    // 进行身份验证
    while (isRunning) {
        recv(clientSocket, username, sizeof(username), 0);
        recv(clientSocket, password, sizeof(password), 0);
        // 验证用户名和密码
        if (userCredentials[username] != password) {
            int buffer = -1; // 认证失败
            send(clientSocket, (char*)&buffer, sizeof(buffer), 0);
        }
        else {
            break;
        }
    }

    int clientID = nextClientID++;                 // 为新客户端分配ID
    clients.emplace_back(clientSocket, clientID);  // 添加客户端
    clientNicknames[clientID] = username;          // 记录客户端昵称

    Logger::log("客户端 " + std::to_string(clientID) + " 已连接。昵称: " + username);
    send(clientSocket, (char*)&clientID, sizeof(clientID), 0);  // 发送分配的客户端ID

    // 发送欢迎消息
    Message welcomeMsg = { SYSTEM, 0, -1, "服务器", "", "" };
    std::string welcomeMessage = "欢迎 " + std::string(username) + " 加入聊天室！";
    strncpy_s(welcomeMsg.content, welcomeMessage.c_str(), sizeof(welcomeMsg.content) - 1);

    std::time_t now = std::time(nullptr);
    struct tm timeinfo;
    localtime_s(&timeinfo, &now);
    std::strftime(welcomeMsg.time, sizeof(welcomeMsg.time), "%Y-%m-%d %H:%M:%S", &timeinfo);
    broadcastMessage(welcomeMsg, 0);

    // 发送聊天室规则
    Message joinMsg = { SYSTEM, 0, clientID, "服务器", "", "" };
    std::string joinMessage = "请遵守以下规则：\n"
        "1. 输入消息后按回车发送。\n"
        "2. 私聊请使用 /p <用户ID> <消息>。\n"
        "3. 输入 /list 查看在线用户。\n"
        "4. 输入 /help 获取帮助。";
    strncpy_s(joinMsg.content, joinMessage.c_str(), sizeof(joinMsg.content) - 1);
    sendMessage(joinMsg);
    // 处理客户端消息
    try {
        while (isRunning) {
            Message msg;
            int bytesRead = recv(clientSocket, (char*)&msg, sizeof(msg), 0);
            if (bytesRead <= 0) {
                Logger::log("客户端 " + std::to_string(clientID) + (bytesRead == SOCKET_ERROR ? " 接收失败: " : " 断开连接。") + getErrorMessage(WSAGetLastError()));
                break;
            }
            Logger::log("[" + std::string(msg.time) + " - " + std::to_string(msg.senderID) + " - " + msg.nickname + " - " + std::to_string(msg.targetID) + "]: " + msg.content);
            if (msg.type == COMMAND) {
                handleClientCommands(msg, clientID);
            }
            else {
                sendMessage(msg);
            }
        }
    }
    catch (const std::exception& e) {
        Logger::log("处理客户端 " + std::to_string(clientID) + " 时发生异常: " + e.what());
    }
    // 客户端离开时清理
    clients.erase(std::remove_if(clients.begin(), clients.end(), [clientID](const auto& c) {
        return c.second == clientID;
        }), clients.end());
    clientNicknames.erase(clientID);
    closesocket(clientSocket);
    // 广播用户离开信息
    Message leftMsg = { SYSTEM, 0, -1, "服务器", "", "" };
    std::string leftContent = "用户 " + std::to_string(clientID) + " 已离开聊天室。";
    strncpy_s(leftMsg.content, leftContent.c_str(), sizeof(leftMsg.content) - 1);
    now = std::time(nullptr);
    localtime_s(&timeinfo, &now);
    std::strftime(leftMsg.time, sizeof(leftMsg.time), "%Y-%m-%d %H:%M:%S", &timeinfo);
    broadcastMessage(leftMsg, 0);
}

// 发送消息
void ChatServer::sendMessage(const Message& msg) {
    if (msg.targetID != -1) {  // 私聊消息
        auto it = std::find_if(clients.begin(), clients.end(), [targetID = msg.targetID](const auto& c) {
            return c.second == targetID;
            });
        if (it != clients.end()) {
            send(it->first, (char*)&msg, sizeof(msg), 0);
        }
    }
    else {  // 广播消息
        broadcastMessage(msg, msg.senderID);
    }
}

// 广播消息
void ChatServer::broadcastMessage(const Message& msg, int senderID) {
    for (const auto& client : clients) {
        if (client.second != senderID) {
            send(client.first, (char*)&msg, sizeof(msg), 0);
        }
    }
}

// 处理服务器命令
void ChatServer::handleServerCommands() {
    std::string command;
    while (isRunning) {
        std::getline(std::cin, command);
        if (command == "quit") {
            if (!isRunning) {
                break;
            }
            isRunning = false;
            Logger::log("服务器正在关闭...");
            // 广播服务器关闭信息
            Message shutdownMsg = { SYSTEM, 0, -1, "服务器", "服务器正在关闭。再见！", "" };
            std::time_t now = std::time(nullptr);
            struct tm timeinfo;
            localtime_s(&timeinfo, &now);
            std::strftime(shutdownMsg.time, sizeof(shutdownMsg.time), "%Y-%m-%d %H:%M:%S", &timeinfo);
            broadcastMessage(shutdownMsg, 0);
            cleanup();
        }
        else if (command == "list") {
            std::cout << "在线用户：" << std::endl;
            for (const auto& client : clients) {
                std::cout << "ID: " << client.second << " - 昵称: " << clientNicknames[client.second] << std::endl;
            }
        }
        else if (command == "help") {
            std::cout << "可用命令：\n"
                << " - quit: 关闭服务器\n"
                << " - list: 列出所有在线用户\n"
                << " - help: 显示此帮助信息\n";
        }
    }
}

// 处理客户端命令
void ChatServer::handleClientCommands(const Message& msg, int senderID) {
    if (strcmp(msg.content, "/list") == 0) {
        std::string userList = "在线用户：";
        {
            for (const auto& client : clients) {
                userList += clientNicknames[client.second] + " (ID: " + std::to_string(client.second) + "), ";
            }
        }
        userList = userList.substr(0, userList.length() - 2);

        Message responseMsg = { SYSTEM, 0, senderID, "服务器", "", "" };
        strncpy_s(responseMsg.content, userList.c_str(), sizeof(responseMsg.content) - 1);

        sendMessage(responseMsg);
    }
}

// 初始化服务器
bool ChatServer::initialize() {
    Logger::log("正在初始化服务器...");
    // 初始化 Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        Logger::log("Winsock 初始化失败: " + getErrorMessage(WSAGetLastError()));
        return false;
    }
    // 创建套接字
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        Logger::log("创建套接字失败: " + getErrorMessage(WSAGetLastError()));
        return false;
    }
    // 绑定套接字
    sockaddr_in serverAddr = { 0 };
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);
    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        Logger::log("绑定套接字失败: " + getErrorMessage(WSAGetLastError()));
        return false;
    }
    // 监听套接字
    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        Logger::log("监听套接字失败: " + getErrorMessage(WSAGetLastError()));
        return false;
    }

    isRunning = true;
    Logger::log("服务器已启动，正在监听端口 " + std::to_string(PORT) + "...");
    return true;
}

// 运行服务器
void ChatServer::run() {
    std::thread commandThread(&ChatServer::handleServerCommands, this);
    commandThread.detach();

    while (isRunning) {
        // 接收客户端连接
        sockaddr_in clientAddr;
        int clientAddrSize = sizeof(clientAddr);
        SOCKET clientSocket = accept(serverSocket, (sockaddr*)&clientAddr, &clientAddrSize);

        if (clientSocket == INVALID_SOCKET) {
            Logger::log("接受客户端连接失败: " + getErrorMessage(WSAGetLastError()));
            continue;
        }

        std::thread clientThread(&ChatServer::handleClient, this, clientSocket);
        clientThread.detach();
    }
}

// 清理资源
void ChatServer::cleanup() {
    closesocket(serverSocket);
    WSACleanup();
}

int main() {
    ChatServer server;
    if (server.initialize()) {
        server.run();
    }
    return 0;
}