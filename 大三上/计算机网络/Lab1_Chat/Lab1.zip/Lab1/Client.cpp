﻿#include <iostream>
#include <thread>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <ctime>
#include <string>
#include <stdexcept>
#include <windows.h>
#include <sstream>

#pragma comment(lib, "ws2_32.lib")

// 服务器地址和端口
const int PORT = 8080;
const char* SERVER_IP = "127.0.0.1";

// 消息类型枚举
enum MessageType {
    TEXT,      // 文本消息
    PRIVATE,   // 私聊消息
    SYSTEM,    // 系统消息
    COMMAND    // 命令消息
};

// 消息结构体
struct Message {
    MessageType type;      // 消息类型
    int senderID;          // 发送者ID
    int targetID;          // 目标用户ID（-1表示广播消息）
    char nickname[50];     // 发送者昵称
    char content[512];     // 消息内容
    char time[50];         // 消息时间戳
};

// 聊天客户端类
class ChatClient {
private:
    SOCKET clientSocket;         // 客户端套接字
    int clientID;                // 客户端ID
    std::string nickname;        // 客户端昵称
    bool isRunning;              // 运行标志

    // 获取系统错误信息
    std::string getErrorMessage(int errorCode);

    // 接收消息线程
    void receiveMessages();

    // 发送消息
    void sendMessage(const Message& msg);

    // 设置控制台颜色
    void setConsoleColor(int color);

    // 清理资源
    void cleanup();

public:
    ChatClient() : clientSocket(INVALID_SOCKET), clientID(-1), isRunning(false) {}
    ~ChatClient() { cleanup(); }

    // 初始化客户端
    bool initialize();

    // 身份验证
    void authenticate();

    // 运行客户端
    void run();
};

// 获取系统错误信息
std::string ChatClient::getErrorMessage(int errorCode) {
    char errMsg[512];
    DWORD result = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, errorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        errMsg, sizeof(errMsg), NULL);
    return result ? std::string(errMsg) : "未知错误。";
}

// 接收消息线程
void ChatClient::receiveMessages() {
    try {
        Message msg;
        while (isRunning) {
            int bytesRead = recv(clientSocket, (char*)&msg, sizeof(msg), 0);
            if (bytesRead <= 0) {
                if (!isRunning) {
                    break;
                }
                isRunning = false;
                setConsoleColor(12); // 红色
                std::cout << (bytesRead == SOCKET_ERROR ? "接收消息时发生错误。" : "与服务器断开连接。") << getErrorMessage(WSAGetLastError()) << std::endl;
                setConsoleColor(7); // 恢复默认颜色
                break;
            }

            if (msg.type == SYSTEM && strcmp(msg.content, "服务器正在关闭。再见！") == 0) {
                if (!isRunning) {
                    break;
                }
                isRunning = false;
                setConsoleColor(14); // 黄色
                std::cout << "服务器正在关闭。按回车键退出。" << std::endl;
                setConsoleColor(7); // 恢复默认颜色
                break;
            }

            setConsoleColor(11); // 浅蓝色
            std::cout << "[" << msg.time << "] ";
            setConsoleColor(10); // 绿色
            std::cout << msg.nickname << " (ID: " << msg.senderID << "): ";
            setConsoleColor(7); // 恢复默认颜色
            std::cout << msg.content << std::endl;
        }
    }
    catch (const std::exception& e) {
        if (!isRunning) {
            return;
        }
        setConsoleColor(12); // 红色
        std::cerr << "接收消息时发生异常: " << e.what() << std::endl;
        setConsoleColor(7); // 恢复默认颜色
    }
    cleanup();
}

// 发送消息
void ChatClient::sendMessage(const Message& msg) {
    if (send(clientSocket, (char*)&msg, sizeof(msg), 0) == SOCKET_ERROR) {
        throw std::runtime_error("发送消息失败: " + getErrorMessage(WSAGetLastError()));
    }
}

// 设置控制台颜色
void ChatClient::setConsoleColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

// 初始化客户端
bool ChatClient::initialize() {
    // 初始化 Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "Winsock 初始化失败: " << getErrorMessage(WSAGetLastError()) << std::endl;
        return false;
    }
    // 创建套接字
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET) {
        std::cerr << "创建套接字失败: " << getErrorMessage(WSAGetLastError()) << std::endl;
        return false;
    }
    // 连接服务器
    sockaddr_in serverAddr = { 0 };
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP, &(serverAddr.sin_addr));

    if (connect(clientSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "连接服务器失败: " << getErrorMessage(WSAGetLastError()) << std::endl;
        return false;
    }

    return true;
}

// 身份验证
void ChatClient::authenticate() {
    // 输入用户名和密码进行身份验证
    char username[50], password[50];
    int authResult;
    while (true) {
        std::cout << "请输入用户名: ";
        std::cin.getline(username, sizeof(username));
        if (strlen(username) == 0) {
            std::cerr << "用户名不能为空，请重新输入。" << std::endl;
            continue;
        }
        std::cout << "请输入密码: ";
        std::cin.getline(password, sizeof(password));
        if (strlen(password) == 0) {
            std::cerr << "密码不能为空，请重新输入。" << std::endl;
            continue;
        }

        send(clientSocket, username, sizeof(username), 0);
        send(clientSocket, password, sizeof(password), 0);
        recv(clientSocket, (char*)&clientID, sizeof(clientID), 0);

        if (clientID != -1) {
            break;
        }
        std::cerr << "用户名或密码错误，请重新输入。" << std::endl;
    }
    nickname = username;
    std::cout << "登录成功！您的ID是: " << clientID << std::endl;
    isRunning = true;
}

// 运行客户端
void ChatClient::run() {
    // 启动接收消息的线程
    std::thread(&ChatClient::receiveMessages, this).detach();

    Message msg = { TEXT, clientID, -1, "", "", "" };
    strncpy_s(msg.nickname, sizeof(msg.nickname), nickname.c_str(), _TRUNCATE);
    // 主循环，发送消息
    try {
        while (isRunning) {
            std::string input;
            std::getline(std::cin, input);

            std::time_t now = std::time(nullptr);
            struct tm timeinfo;
            localtime_s(&timeinfo, &now);
            std::strftime(msg.time, sizeof(msg.time), "%Y-%m-%d %H:%M:%S", &timeinfo);
            // 处理命令
            if (input == "/quit") {
                isRunning = false;
                setConsoleColor(14); // 黄色
                std::cout << "感谢使用！程序将关闭。" << std::endl;
                setConsoleColor(7); // 恢复默认颜色
                break;
            }
            else if (input.substr(0, 3) == "/p ") {
                std::istringstream iss(input.substr(3));
                int targetID;
                if (iss >> targetID) {
                    std::string privateMsg;
                    std::getline(iss >> std::ws, privateMsg);
                    if (!privateMsg.empty()) {
                        msg.type = PRIVATE;
                        msg.targetID = targetID;
                        strncpy_s(msg.content, privateMsg.c_str(), sizeof(msg.content) - 1);
                    }
                    else {
                        setConsoleColor(12); // 红色
                        std::cout << "私聊消息不能为空。" << std::endl;
                        setConsoleColor(7); // 恢复默认颜色
                        continue;
                    }
                }
                else {
                    setConsoleColor(12); // 红色
                    std::cout << "无效的私聊命令格式。使用 /p <用户ID> <消息>" << std::endl;
                    setConsoleColor(7); // 恢复默认颜色
                    continue;
                }
            }
            else if (input == "/list") {
                msg.type = COMMAND;
                msg.targetID = -1;
                strcpy_s(msg.content, "/list");
            }
            else if (input == "/help") {
                setConsoleColor(14); // 黄色
                std::cout << "可用命令：\n"
                    << " - /quit: 退出聊天\n"
                    << " - /p <用户ID> <消息>: 发送私聊消息\n"
                    << " - /list: 列出所有在线用户\n"
                    << " - /help: 显示此帮助信息\n";
                setConsoleColor(7); // 恢复默认颜色
                continue;
            }
            else {
                msg.type = TEXT;
                msg.targetID = -1;
                strncpy_s(msg.content, input.c_str(), sizeof(msg.content) - 1);
            }
            sendMessage(msg);
        }
    }
    catch (const std::exception& e) {
        if (!isRunning) {
            return;
        }
        setConsoleColor(12); // 红色
        std::cerr << "发生异常: " << e.what() << std::endl;
        setConsoleColor(7); // 恢复默认颜色
    }
    cleanup();
}

// 清理资源
void ChatClient::cleanup() {
    if (clientSocket != INVALID_SOCKET) {
        closesocket(clientSocket);
        WSACleanup();
    }
}

int main() {
    ChatClient client;
    if (client.initialize()) {
        client.authenticate();
        client.run();
    }
    return 0;
}