import numpy as np
from scipy import sparse
from typing import List
import random
from collections import Counter

class matCoo:
    def __init__(self, n: int = 0, m: int = 0):
        self.n = n
        self.m = m
        self.elem = []
        self.totalElements = 0

    def createMat(self, n: int, m: int):
        self.n = n
        self.m = m
        self.elem.clear()
        self.totalElements = 0

    def matTimes(self, c: float):
        if c == 0:
            self.elem.clear()
            self.totalElements = 0
        else:
            self.elem = [(row, col, val * c) for row, col, val in self.elem]

    def append(self, row: int, col: int, val: float):
        if not np.isclose(val, 0):
            self.elem.append((row, col, val))
            self.totalElements += 1

    def to_scipy_coo(self):
        if not self.elem:
            return sparse.coo_matrix(([], ([], [])), shape=(self.n, self.m))
        rows, cols, data = zip(*sorted(self.elem))
        return sparse.coo_matrix((data, (rows, cols)), shape=(self.n, self.m))

class mat:
    def __init__(self, n: int = 1, m: int = 1):
        self.n = n
        self.m = m
        self.v = np.zeros((n, m), dtype=float)

    def createMat(self, n: int, m: int):
        self.n = n
        self.m = m 
        self.v = np.zeros((n, m), dtype=float)

    def matTimes(self, c: float):
        self.v *= c

    def findDiff(self, other: 'mat') -> float:
        if self.n != other.n or self.m != other.m:
            return -1
        return np.sum(np.abs(self.v - other.v))

    def setneg(self):
        self.v.fill(-1)

    def editval(self, x: int, y: int, val: float):
        self.v[x, y] = val

    def getval(self, x: int, y: int) -> float:
        return self.v[x, y]

    def editval2(self, x: int, y: int):
        self.v[x, :] = 0
        self.v[x, y] = 1

def matMultiply(x1: matCoo, x2: mat, res: mat):
    coo_m = x1.to_scipy_coo()
    res.v = coo_m.dot(x2.v)

def calculate_neighbor_weights(sorted_elem, start_idx, end_idx, node_idx):
    """优化的邻居节点权重计算"""
    weights = []
    neighbors = []
    for j in range(start_idx, end_idx):
        neighbor_idx = sorted_elem[j][1]
        edge_weight = sorted_elem[j][2]
        weights.append((neighbor_idx, edge_weight))
        neighbors.append(neighbor_idx)
    return weights, neighbors

def weighted_label_vote(weights, y_ori, neighbor_indices):
    """改进的带权重标签投票"""
    vote_dict = {}
    for (idx, weight), neighbor_idx in zip(weights, neighbor_indices):
        if 0 <= idx < y_ori.shape[0]:  # 添加边界检查
            label = y_ori[idx, 0]
            vote_dict[label] = vote_dict.get(label, 0) + weight
    return max(vote_dict.items(), key=lambda x: x[1]) if vote_dict else (None, 0)

def dataProcess(y_old: mat, y_new: mat, preserved: float = 0.8, changed: float = 0.1, masked: float = 0.1):
    n0, m0 = y_old.n, y_old.m
    y_new.createMat(n0, m0)
    y_new.setneg()

    r = np.random.rand(n0)
    mask_preserved = r < preserved
    mask_changed = (r >= preserved) & (r < preserved + changed)
    mask_masked = r >= preserved + changed

    # 保留标签
    y_new.v[mask_preserved] = y_old.v[mask_preserved]
    # 标记缺失
    y_new.v[mask_masked] = -1

    # 随机修改标签
    changed_indices = np.where(mask_changed)[0]
    for i in changed_indices:
        if y_old.v[i, 0] != -1:
            available_labels = list(range(m0))
            current_label = np.where(y_old.v[i] == 1)[0][0]
            available_labels.remove(current_label)
            if available_labels:
                new_label = random.choice(available_labels)
                y_new.v[i] = 0
                y_new.v[i, new_label] = 1

def rectify(x: matCoo, y_label: mat, y_ori: mat, y_new: mat, base_confidence: float = 0.5):
    """改进的标签修正函数"""
    y_new.v = y_ori.v.copy()
    if not x.elem:
        return

    sorted_elem = sorted(x.elem, key=lambda e: (e[0], e[1]))

    curr_row = 0
    for i in range(y_label.n):
        if y_label.v[i, 0] == -1:
            continue

        # 找到当前节点的邻居
        while curr_row < len(sorted_elem) and sorted_elem[curr_row][0] < i:
            curr_row += 1
        start_idx = curr_row
        while curr_row < len(sorted_elem) and sorted_elem[curr_row][0] == i:
            curr_row += 1
        end_idx = curr_row

        # 获取邻居权重和索引
        neighbor_weights, neighbor_indices = calculate_neighbor_weights(
            sorted_elem, start_idx, end_idx, i)
        
        if not neighbor_weights:  # 跳过没有邻居的节点
            continue
            
        current_label = y_ori.v[i, 0]
        
        # 使用改进的投票机制
        best_label, confidence = weighted_label_vote(
            neighbor_weights, y_ori.v, neighbor_indices)

        # 动态计算置信度阈值
        num_neighbors = len(neighbor_weights)
        dynamic_confidence = base_confidence + (1 - base_confidence) * (1 - 1 / (1 + num_neighbors))

        # 根据动态置信度修改标签
        if best_label is not None and confidence > dynamic_confidence:
            if best_label != current_label:
                y_new.v[i, 0] = best_label

def labelPropagation(
    X: matCoo,
    y_label: mat, 
    y_pred: mat,
    y_res: mat,
    alpha: float = 0.3,    # 降低alpha增加稳定性
    max_iter: int = 2000,  # 增加迭代次数
    tol: float = 1e-6      # 提高收敛精度
):
    """改进的标签传播算法"""
    n_samples = X.n
    n_classes = y_label.m

    # 优化权重矩阵
    W = X.to_scipy_coo()
    # 使用改进的权重变换
    W.data = np.exp(-alpha * (W.data ** 2)) / (1 + np.exp(-alpha * (W.data ** 2)))
    
    # 添加自环
    self_loop = sparse.eye(n_samples, format='coo')
    W = W + 0.1 * self_loop
    
    # 改进的标准化
    row_sum = np.array(W.sum(axis=1)).flatten()
    row_sum[row_sum == 0] = 1e-9
    D_inv = sparse.diags(1.0 / np.sqrt(row_sum))
    P = D_inv.dot(W).dot(D_inv)  # 对称归一化

    # 初始化
    Y_init = y_label.v.copy()
    Y_new = np.zeros_like(Y_init)
    Y_history = []  # 记录历史状态
    
    # 迭代传播
    for iter_count in range(max_iter):
        Y_old = Y_new.copy()
        
        # 标签传播
        Y_new = P.dot(Y_init)
        
        # 标签平滑
        if iter_count > 0:
            Y_new = 0.8 * Y_new + 0.2 * Y_old
        
        # 归一化
        row_sums = Y_new.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1e-9
        Y_new /= row_sums
        
        # 保持已标记节点的标签
        labeled_mask = (y_label.v != -1)
        Y_new[labeled_mask] = y_label.v[labeled_mask]
        
        # 记录历史
        Y_history.append(Y_new.copy())
        if len(Y_history) > 3:
            Y_history.pop(0)
        
        # 改进的收敛检查
        diff = np.sum(np.abs(Y_new - Y_old)) / n_samples
        if diff < tol and len(Y_history) > 2:
            # 检查最近3次迭代的稳定性
            diffs = [np.sum(np.abs(Y_history[i+1] - Y_history[i])) 
                    for i in range(len(Y_history)-1)]
            if all(d < tol for d in diffs):
                break
            
        Y_init = Y_new.copy()

    # 预测标签
    y_pred.v = np.argmax(Y_new, axis=1).reshape(-1, 1)
    
    # 改进的标签修正
    rectify(X, y_label, y_pred, y_res, confidence_threshold=0.75)