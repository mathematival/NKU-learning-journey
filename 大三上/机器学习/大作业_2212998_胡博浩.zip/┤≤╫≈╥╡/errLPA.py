import scanpy as sc
import time
import random
import numpy as np
import pandas as pd
import LPA as LPA
from sklearn.metrics.cluster import adjusted_rand_score

df = pd.DataFrame(columns=['MR', 'ARI_o', 'ARI_r', 'Time'])

start = time.time()

# Read dataset
adata = sc.read('E:/Downloads/24机器学习大作业/code/dataset.h5ad')
sc.pp.neighbors(adata)

mat = adata.obsp['connectivities']
coo = mat.tocoo()
rows, cols, data = coo.row, coo.col, coo.data

mat_labels = adata.obs['annotation'].values
unique_labels = np.unique(mat_labels)
val = {label: idx for idx, label in enumerate(unique_labels)}

k1 = 1.0
while True:
    for _ in range(100):
        X = LPA.matCoo(mat.shape[0], mat.shape[0])
        for i in range(len(data)):
            X.append(rows[i], cols[i], data[i])

        y_label = LPA.mat(mat.shape[0], len(val))
        y_label.setneg()

        y_new = LPA.mat(mat.shape[0], len(val))
        random_indexes = random.sample(range(mat.shape[0]), int(mat.shape[0] * 0.1))
        for i in random_indexes:
            label_idx = val[mat_labels[i]]
            y_label.editval2(i, label_idx)

        y_pred = LPA.mat(mat.shape[0], len(val))
        y_res = LPA.mat(mat.shape[0], len(val))

        start_time = time.perf_counter()
        LPA.dataProcess(y_label, y_new, k1, (1 - k1), 0)
        LPA.labelPropagation(X, y_new, y_pred, y_res, 0.5, 1000)
        end_time = time.perf_counter()
        execution_time = end_time - start_time

        res_arr = np.zeros(mat.shape[0])
        for i in range(mat.shape[0]):
            res_arr[i] = y_pred.getval(i, 0)
        ari_o = adjusted_rand_score(mat_labels, res_arr)

        res_arr2 = np.zeros(mat.shape[0])
        for i in range(mat.shape[0]):
            res_arr2[i] = y_res.getval(i, 0)
        ari_r = adjusted_rand_score(mat_labels, res_arr2)

        item = [round((1 - k1), 2), ari_o, ari_r, round(execution_time, 5)]
        print(item)
        df.loc[len(df)] = item

    k1 -= 0.05
    print(k1)
    if k1 < 0:
        break

df.to_csv("mistake.tsv", sep='\t', header=True, index=True)

end = time.time()
print("time: {}".format(end - start))