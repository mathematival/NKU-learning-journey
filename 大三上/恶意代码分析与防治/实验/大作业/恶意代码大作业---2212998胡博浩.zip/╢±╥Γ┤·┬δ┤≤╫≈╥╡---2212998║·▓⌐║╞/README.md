ember：模型源代码

ember2018-notebook.ipynb：模型评估结果

scripts：编写的测试恶意代码实验所有样本的脚本 test.bat、以及相应的脚本运行结果 result.txt

