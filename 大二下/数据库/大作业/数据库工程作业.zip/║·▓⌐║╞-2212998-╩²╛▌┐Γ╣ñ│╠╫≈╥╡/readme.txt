一共提交三个文件，分别为建数据库的manga.sql文件，程序源码的manga.zip文件，数据库工程作业报告。

如何让这个代码在你的电脑上跑起来？
1. 确保你的电脑上装了Java，Mysql，IDEA。
2. 将程序源码中libs的mysql-connector加入到你的项目中（在IDEA的程序结构中添加模块）
3. 首先运行sql文件初始化数据库，数据库初始化后，前往src/kernel/util/DbUtils.java中修改为自己的数据库
4.如果需要可视化，可以安装sceneBuilder、并链接到IDEA中