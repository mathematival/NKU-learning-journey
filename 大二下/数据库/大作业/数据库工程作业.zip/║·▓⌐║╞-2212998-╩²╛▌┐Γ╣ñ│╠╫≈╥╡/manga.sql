/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80025
 Source Host           : localhost:3306
 Source Schema         : manga

 Target Server Type    : MySQL
 Target Server Version : 80025
 File Encoding         : 65001

 Date: 03/06/2024 22:45:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `userName` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `passWord` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, '旅行者', '123');
INSERT INTO `admin` VALUES (2, '空想家', 'think');
INSERT INTO `admin` VALUES (3, '记录官', 'write');
INSERT INTO `admin` VALUES (4, '窥秘人', 'see');
INSERT INTO `admin` VALUES (5, '愚者', 'god');

-- ----------------------------
-- Table structure for generaluser
-- ----------------------------
DROP TABLE IF EXISTS `generaluser`;
CREATE TABLE `generaluser`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `userName` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `passWord` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `realName` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `idCard` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `phone` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `address` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `id`(`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 121 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of generaluser
-- ----------------------------
INSERT INTO `generaluser` VALUES (1, '克莱恩', 'test', '周明瑞', '012345678912345678', '98765432100', '灰雾');
INSERT INTO `generaluser` VALUES (2, '正义', '123', '奥黛丽', '110101200108073361', '14613842106', '贝克兰德');
INSERT INTO `generaluser` VALUES (3, '倒吊人', '123', '阿尔杰', '', '', '');
INSERT INTO `generaluser` VALUES (4, '太阳', 'Qiqi', '戴里克', '', '', '白银之城');
INSERT INTO `generaluser` VALUES (5, '魔术师', 'Ningguang', '佛尔思', '', '', '亚伯拉罕');
INSERT INTO `generaluser` VALUES (101, '月亮', 'Sucrose', '埃姆林', '501238102', '3123', '吸血鬼');
INSERT INTO `generaluser` VALUES (102, '隐者', '34546758', '嘉德丽雅', '', '15403', '星象师');
INSERT INTO `generaluser` VALUES (110, '梦魇', '123', '伦纳德', '', '', '红手套');
INSERT INTO `generaluser` VALUES (111, '阿尔斯通', 'test', '多吃蔬菜', '3243543453453', '242524544343', '舒服舒服');
INSERT INTO `generaluser` VALUES (112, '值夜者', '123', '邓恩', 'safaf', 'ffff', '永远的队长');
INSERT INTO `generaluser` VALUES (116, '死神', '123', '戴莉', '', '', '死灵导师');

-- ----------------------------
-- Table structure for manga
-- ----------------------------
DROP TABLE IF EXISTS `manga`;
CREATE TABLE `manga`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `coverPath` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `name` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `publisher` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cycle` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `price` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` varchar(140) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `classNumber` int(0) NOT NULL DEFAULT 2333,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `classNumber`(`classNumber`) USING BTREE,
  CONSTRAINT `manga_class` FOREIGN KEY (`classNumber`) REFERENCES `mclass` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1401 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of manga
-- ----------------------------
INSERT INTO `manga` VALUES (1, 'OnePunchMan.jpg', '一拳超人', '集英社', '周刊', '36', '《一拳超人》讲述了主人公琦玉的故事，他通过锻炼成为了一名强大的超级英雄，但因为太过强大而感到无聊。这部漫画融合了动作、喜剧和超级英雄元素，以及对英雄主义的讽刺和反思。', 1);
INSERT INTO `manga` VALUES (2, 'Naruto.jpg', '火影忍者', '集英社', '周刊', '17', '故事以年轻的忍者火影之子漩涡鸣人为中心，描述了他成长为村里最强忍者的旅程。他与伙伴们一起经历了训练、战斗、友情和牺牲，最终实现了自己成为火影的梦想。', 1);
INSERT INTO `manga` VALUES (3, 'Bleach.jpg', '死神', '集英社', '周刊', '8', '《死神》讲述了普通少年黒崎一护意外成为死神的故事。作为死神，他的任务是保护人类免受邪恶灵魂的侵害，并解决来自灵界的各种威胁。在他的冒险中，他结识了许多强大的盟友，对抗了各种强大的敌人，同时也探索了灵界的秘密和自己的身世之谜。', 1);
INSERT INTO `manga` VALUES (4, 'DemonSlayer.jpg', '鬼灭之刃', '集英社', '年刊', '43', '《鬼灭之刃》讲述了主人公炭治郎的故事，他成为了鬼杀队的一员，目标是为了报仇，讨伐杀害家人的鬼。这是一部充满动作场面和精彩战斗的漫画，同时也融合了冒险和奇幻的元素。', 1);
INSERT INTO `manga` VALUES (5, 'OnePiece.jpg', '海贼王', '集英社', '周刊', '8', '讲述了路飞和他的海贼团航行在大海上的冒险故事，追逐传说中的宝藏“One Piece”，在旅途中与各种劲敌战斗，结交伙伴，不断成长。', 2);
INSERT INTO `manga` VALUES (6, 'AttackOnTitan.jpg', '进击的巨人', '講談社', '月刊', '35', ' 在一个被庞大的人类吞噬者巨人支配的世界里，人类建立起了高耸的墙以保护自己。故事围绕着主人公艾伦·耶格尔及其朋友们展开，他们加入了人类最后的希望——侦查兵团，与巨人展开了生死搏斗，同时揭开了巨人背后的秘密。', 2);
INSERT INTO `manga` VALUES (7, 'SoulEater.jpg', '闪灵二人组', '方志社', '季刊', '42', '《闪灵二人组》是一部以死神和他们的武器为主角的漫画，他们在收集魂魄的过程中对抗恶灵和邪恶势力。故事充满了动作、幽默和冒险元素。', 2);
INSERT INTO `manga` VALUES (8, 'CaseClosed.jpg', '名侦探柯南', '小学馆', '不定期', '30', '《名侦探柯南》是一部以推理为主题的漫画，讲述了高中生工藤新一在一次调查中被不明药物缩小成小学生的身体，随后化名江户川柯南，以侦探助手的身份潜入黑暗的犯罪世界，一边寻找变身的解药，一边揭开各种案件的真相。', 3);
INSERT INTO `manga` VALUES (9, 'DeathNote.jpg', '死亡笔记', '集英社', '年刊', '34', '《死亡笔记》讲述了主人公夜神月获得了一本名为「死亡笔记」的神秘笔记本，只需写上人名并心中想着他们的脸，就能让被写名字的人死亡。夜神月利用死亡笔记展开了一场挑战正义的游戏，试图建立一个新世界秩序。这部漫画充满了悬疑、心理对决和道德辩证的元素。', 3);
INSERT INTO `manga` VALUES (10, 'Gintama.jpg', '银魂', '集英社', '半月刊', '28', '《银魂》是一部以幽默搞笑为主，但也融合了动作、冒险和科幻元素的漫画。故事发生在一个由外星人占领的江户时代，主要讲述了以萨摩银时为首的一群“万事屋”成员的滑稽生活和与外星人的斗争。', 4);
INSERT INTO `manga` VALUES (11, 'YourName.jpg', '你的名字', 'Kadokawa', '月刊', '35', '这是一部感人至深的爱情故事，讲述了两个年轻人，男孩宫水三叶和女孩立花瀧，因神秘力量而交换身体并开始相互了解的故事。他们穿越时间和空间的障碍，努力寻找彼此，同时揭示了一个古老的神秘。', 5);
INSERT INTO `manga` VALUES (12, 'JoJo\'sBizarreAdventure.jpg', 'JOJO的奇妙冒险', '集英社', '双月刊', '27', '《JOJO的奇妙冒险》是一部由荒木飞呼创作的漫画，讲述了乔斯达家族及其后裔们的冒险故事。每一部作品都有不同的主角、故事背景和敌人，以及充满创意和独特风格的战斗场面。', 6);
INSERT INTO `manga` VALUES (13, 'DragonBall.jpg', '龙珠', '集英社', '周刊', '9', '《龙珠》是一部以孙悟空为主角的冒险故事，讲述了他与朋友们一起寻找神龙，收集龙珠，实现各种愿望的故事。随着故事的发展，孙悟空和他的朋友们不断面对各种挑战，包括强大的敌人和冒险充满的旅程。这部漫画在全球范围内都享有极高的声誉和知名度，被视为日本漫画界的经典之作。', 6);
INSERT INTO `manga` VALUES (14, 'Kingdom.jpg', '王者天下', '少年画报社', '不定期', '33', '《王者天下》以中国战国时代为背景，讲述了主人公信的成长历程以及他在战国乱世中的奋斗和努力。故事充满了战争策略、政治斗争、人物塑造等元素，展现了中国古代战国时代的风云变幻和百家争鸣的历史场景。', 7);

-- ----------------------------
-- Table structure for mclass
-- ----------------------------
DROP TABLE IF EXISTS `mclass`;
CREATE TABLE `mclass`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `className` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2334 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mclass
-- ----------------------------
INSERT INTO `mclass` VALUES (1, '动作');
INSERT INTO `mclass` VALUES (2, '冒险');
INSERT INTO `mclass` VALUES (3, '悬疑');
INSERT INTO `mclass` VALUES (4, '喜剧');
INSERT INTO `mclass` VALUES (5, '爱情');
INSERT INTO `mclass` VALUES (6, '幻想');
INSERT INTO `mclass` VALUES (7, '未分类');

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `uid` int(0) NOT NULL,
  `mid` int(0) NOT NULL,
  `cycleNum` int(0) NOT NULL,
  `copiesNum` int(0) NOT NULL,
  `totalPrice` int(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE,
  INDEX `mangaToOrder`(`mid`) USING BTREE,
  CONSTRAINT `mangaToOrder` FOREIGN KEY (`mid`) REFERENCES `manga` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_uid` FOREIGN KEY (`uid`) REFERENCES `generaluser` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES (1, 1, 4, 1, 1, 43);
INSERT INTO `order` VALUES (2, 1, 1, 4, 1, 144);
INSERT INTO `order` VALUES (3, 2, 12, 2, 5, 270);
INSERT INTO `order` VALUES (4, 3, 10, 6, 1, 168);
INSERT INTO `order` VALUES (5, 5, 7, 1, 3, 126);
INSERT INTO `order` VALUES (6, 101, 2, 2, 2, 68);
INSERT INTO `order` VALUES (7, 3, 4, 3, 4, 516);
INSERT INTO `order` VALUES (8, 4, 6, 6, 3, 630);
INSERT INTO `order` VALUES (9, 5, 7, 5, 4, 840);
INSERT INTO `order` VALUES (10, 101, 9, 4, 7, 952);
INSERT INTO `order` VALUES (11, 102, 13, 5, 3, 135);
INSERT INTO `order` VALUES (12, 110, 5, 7, 3, 168);
INSERT INTO `order` VALUES (13, 1, 2, 1, 3, 51);
INSERT INTO `order` VALUES (14, 1, 3, 1, 5, 40);
INSERT INTO `order` VALUES (15, 1, 5, 1, 2, 16);
INSERT INTO `order` VALUES (16, 1, 8, 1, 4, 120);
INSERT INTO `order` VALUES (17, 1, 9, 1, 2, 68);
INSERT INTO `order` VALUES (18, 1, 10, 1, 3, 84);
INSERT INTO `order` VALUES (19, 2, 11, 6, 6, 1260);
INSERT INTO `order` VALUES (20, 2, 10, 8, 8, 1792);

-- ----------------------------
-- View structure for classreview
-- ----------------------------
DROP VIEW IF EXISTS `classreview`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `classreview` AS select coalesce(`c`.`className`,'总数') AS `className`,sum(`o`.`totalPrice`) AS `totalPrice`,count(0) AS `orderNum` from ((`order` `o` join `manga` `m`) join `mclass` `c`) where ((`m`.`id` = `o`.`mid`) and (`c`.`id` = `m`.`classNumber`)) group by `c`.`className` with rollup;

-- ----------------------------
-- View structure for mangareview
-- ----------------------------
DROP VIEW IF EXISTS `mangareview`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `mangareview` AS select coalesce(`m`.`name`,'总数') AS `mangaName`,sum(`o`.`totalPrice`) AS `totalPrice`,count(0) AS `orderNum` from (`order` `o` join `manga` `m`) where (`m`.`id` = `o`.`mid`) group by `m`.`name` with rollup;

-- ----------------------------
-- View structure for seclassreview
-- ----------------------------
DROP VIEW IF EXISTS `seclassreview`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `seclassreview` AS select `classreview`.`className` AS `className`,`classreview`.`totalPrice` AS `totalPrice`,`classreview`.`orderNum` AS `orderNum` from `classreview` where `classreview`.`totalPrice` in (select max(`classreview`.`totalPrice`) from `classreview`) is false;

-- ----------------------------
-- View structure for semangareview
-- ----------------------------
DROP VIEW IF EXISTS `semangareview`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `semangareview` AS select `mangareview`.`mangaName` AS `mangaName`,`mangareview`.`totalPrice` AS `totalPrice`,`mangareview`.`orderNum` AS `orderNum` from `mangareview` where `mangareview`.`totalPrice` in (select max(`mangareview`.`totalPrice`) from `mangareview`) is false;

-- ----------------------------
-- View structure for seuserreview
-- ----------------------------
DROP VIEW IF EXISTS `seuserreview`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `seuserreview` AS select `userreview`.`userName` AS `userName`,`userreview`.`totalPrice` AS `totalPrice`,`userreview`.`orderNum` AS `orderNum` from `userreview` where `userreview`.`totalPrice` in (select max(`userreview`.`totalPrice`) from `userreview`) is false;

-- ----------------------------
-- View structure for userreview
-- ----------------------------
DROP VIEW IF EXISTS `userreview`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `userreview` AS select coalesce(`u`.`userName`,'总数') AS `userName`,sum(`o`.`totalPrice`) AS `totalPrice`,count(0) AS `orderNum` from (`order` `o` join `generaluser` `u`) where (`u`.`id` = `o`.`uid`) group by `u`.`userName` with rollup;

-- ----------------------------
-- Procedure structure for DeleteUserAndOrders
-- ----------------------------
DROP PROCEDURE IF EXISTS `DeleteUserAndOrders`;
delimiter ;;
CREATE PROCEDURE `DeleteUserAndOrders`(IN userId INT)
BEGIN
    -- 处理异常
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- 如果发生异常，回滚事务
        ROLLBACK;
				-- 抛出异常或记录错误
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An error occurred while deleting user	and orders';
    END;
		
    -- 开始事务
    START TRANSACTION;
    
    -- 删除与特定用户相关的订单
    DELETE FROM `order`
    WHERE `uid` = userId;
    
    -- 删除特定的用户
    DELETE FROM `generaluser`
    WHERE `id` = userId;
    
    -- 提交事务
    COMMIT;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for UpdateMangaPriceAndOrderTotal
-- ----------------------------
DROP PROCEDURE IF EXISTS `UpdateMangaPriceAndOrderTotal`;
delimiter ;;
CREATE PROCEDURE `UpdateMangaPriceAndOrderTotal`(IN mangaId INT, IN newPrice INT)
BEGIN
    -- 检查新价格是否大于0且小于999
    IF newPrice <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '价格必须大于0';
    ELSEIF newPrice >= 999 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '价格必须小于999';
    END IF;

    -- 更新漫画表中的价格
    UPDATE manga SET price = newPrice WHERE id = mangaId;

    -- 更新所有相关订单中的总价格
    UPDATE `order` 
    SET totalPrice = cycleNum * copiesNum * newPrice
    WHERE mid = mangaId;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table admin
-- ----------------------------
DROP TRIGGER IF EXISTS `tr_unique_admin_id`;
delimiter ;;
CREATE TRIGGER `tr_unique_admin_id` BEFORE INSERT ON `admin` FOR EACH ROW BEGIN
    -- 检查新用户ID是否已存在
    IF EXISTS (SELECT 1 FROM admin WHERE id = NEW.id) THEN
        SIGNAL SQLSTATE '45001'
        SET MESSAGE_TEXT = 'User ID already exists. Please choose a different ID.';
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table admin
-- ----------------------------
DROP TRIGGER IF EXISTS `tr_unique_admin_username`;
delimiter ;;
CREATE TRIGGER `tr_unique_admin_username` BEFORE INSERT ON `admin` FOR EACH ROW BEGIN
    -- 检查新用户名是否已存在
    IF EXISTS (SELECT 1 FROM admin WHERE userName = NEW.userName) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Username already exists. Please choose a different username.';
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table generaluser
-- ----------------------------
DROP TRIGGER IF EXISTS `tr_unique_userid`;
delimiter ;;
CREATE TRIGGER `tr_unique_userid` BEFORE INSERT ON `generaluser` FOR EACH ROW BEGIN
    -- 检查新用户ID是否已存在
    IF EXISTS (SELECT 1 FROM generaluser WHERE id = NEW.id) THEN
        SIGNAL SQLSTATE '45001'
        SET MESSAGE_TEXT = 'User ID already exists. Please choose a different ID.';
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table generaluser
-- ----------------------------
DROP TRIGGER IF EXISTS `tr_unique_username`;
delimiter ;;
CREATE TRIGGER `tr_unique_username` BEFORE INSERT ON `generaluser` FOR EACH ROW BEGIN
    -- 检查新用户名是否已存在
    IF EXISTS (SELECT 1 FROM generaluser WHERE userName = NEW.userName) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Username already exists. Please choose a different username.';
    END IF;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
