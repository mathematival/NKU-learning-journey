wenshin <wenshin2011(at)gmail.com>
* for contributing core code

erevus <zbhack(at)sina.cn>
* for contributing core code

Fooying <f00y1n9(at)gmail.com>
* for contributing core code

Medici.Yan <Medici.Yan(at)gmail.com>
* for contributing doc

phithon <root(at)leavesongs.com>
* for suggesting a couple of features

花开、若相惜 <635484364(at)qq.com>
* for suggesting a couple of features

GurdZain
* for contributing a minor patch

1ookup <377101099(at)qq.com>
* for contributing a minor patch

Jeremy
* for reporting a bug

rains31 <rains31+github(at)gmail.com>
* for contributing packet.py
* for contributing a minor patch

tanjelly
* for contributing a minor path

join-us
* for contributing doc

Xyntax
* PEP8

MyKings
* add English Usage
